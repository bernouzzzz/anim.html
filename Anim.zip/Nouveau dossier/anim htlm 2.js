(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"anim htlm 2_atlas_", frames: [[1890,1729,103,215],[1890,1510,114,217],[1469,1510,125,217],[1271,441,135,217],[1060,1368,143,215],[908,1375,150,211],[1110,888,156,207],[926,1164,161,202],[559,1656,165,196],[740,1599,167,189],[726,1790,168,181],[351,1861,169,173],[1275,1056,168,164],[1722,1674,166,154],[1513,1873,163,144],[1935,208,113,217],[1596,1505,124,217],[1262,665,133,216],[896,1801,142,214],[909,1588,149,211],[1826,0,155,206],[1664,0,160,201],[1110,1097,163,194],[184,1861,165,187],[1040,1806,167,179],[1268,883,167,171],[1722,1510,166,162],[1465,1087,164,152],[1678,1830,161,142],[1397,660,128,215],[1285,219,128,215],[1415,198,128,215],[1545,203,128,215],[1675,203,128,215],[1805,208,128,215],[1201,1585,128,215],[1209,1802,128,215],[1408,436,128,215],[1538,420,128,215],[1668,420,128,215],[1798,425,128,215],[1527,653,128,215],[1657,637,128,215],[1787,642,128,215],[1917,642,128,215],[1205,1293,128,215],[1335,1222,128,215],[1335,1439,128,215],[1339,1656,128,215],[1657,854,128,215],[1787,859,128,215],[1917,859,128,215],[1527,870,128,215],[1657,1071,128,215],[1787,1076,128,215],[1917,1076,128,215],[1465,1293,128,215],[1595,1288,128,215],[1725,1293,128,215],[1855,1293,128,215],[1060,1585,139,219],[1110,665,150,221],[1110,441,159,222],[740,1375,166,222],[1110,219,173,220],[1110,0,178,217],[0,1656,182,214],[740,1164,184,209],[184,1656,186,203],[1290,0,186,196],[372,1656,185,189],[1478,0,184,180],[0,1872,181,171],[522,1854,177,162],[1339,1873,172,152],[1469,1729,167,142],[0,492,368,580],[0,1074,368,580],[370,492,368,580],[370,1074,368,580],[740,0,368,580],[740,582,368,580],[0,0,700,490]]},
		{name:"anim htlm 2_atlas_2", frames: [[0,0,103,215],[105,0,103,215],[210,0,103,215],[315,0,103,215],[420,0,103,215],[525,0,103,215],[630,0,103,215],[735,0,103,215],[840,0,103,215],[945,0,103,215],[1050,0,103,215],[1155,0,103,215],[1260,0,103,215],[1365,0,103,215],[1470,0,103,215],[1575,0,103,215],[1680,0,103,215],[1785,0,103,215],[1890,0,103,215],[0,217,103,215],[105,217,103,215],[210,217,103,215],[315,217,103,215],[420,217,103,215],[525,217,103,215],[630,217,103,215],[735,217,103,215],[840,217,103,215],[945,217,103,215],[1050,217,103,215],[412,651,160,134],[896,651,155,124],[1363,651,150,113],[1813,651,144,103],[1515,764,138,92],[1053,775,131,81],[697,785,123,71],[1805,858,116,61],[526,863,107,51],[1153,863,107,51],[1568,863,107,51],[1677,863,107,51],[0,868,107,51],[109,868,107,51],[218,868,107,51],[1155,217,101,215],[1258,217,101,215],[1361,217,101,215],[1464,217,101,215],[1567,217,101,215],[1670,217,101,215],[1773,217,101,215],[1876,217,101,215],[0,434,101,215],[103,434,101,215],[206,434,101,215],[309,434,101,215],[412,434,101,215],[515,434,101,215],[618,434,101,215],[721,434,101,215],[824,434,101,215],[927,434,101,215],[1030,434,101,215],[1133,434,101,215],[1236,434,101,215],[1339,434,101,215],[1442,434,101,215],[1545,434,101,215],[1648,434,101,215],[1751,434,101,215],[1854,434,101,215],[0,651,101,215],[103,651,101,215],[206,651,101,215],[309,651,101,215],[736,651,158,132],[1053,651,153,122],[1515,651,148,111],[1813,756,142,100],[1363,766,135,90],[896,777,128,79],[412,787,121,69],[1923,858,113,59],[526,916,105,49],[1153,916,105,49],[1568,916,105,49],[1675,916,105,49],[1923,919,105,49],[0,921,105,49],[107,921,105,49],[574,651,160,131],[1208,651,153,120],[1665,651,146,109],[1665,762,138,99],[1208,773,130,88],[574,784,121,77],[412,858,112,67],[697,858,112,67],[811,858,112,67],[925,858,112,67],[1039,858,112,67],[1340,858,112,67],[1454,858,112,67]]}
];


// symbols:



(lib.CachedBmp_180 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_179 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_178 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_177 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_176 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_175 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_174 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_173 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_172 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_171 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_170 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_169 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_168 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_167 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_166 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_165 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_164 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_163 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_162 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_161 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_160 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_159 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_158 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_157 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_156 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_155 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_154 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_153 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_152 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_151 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_150 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_149 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_148 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_147 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_146 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_145 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_144 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_143 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_142 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_141 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_140 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_139 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_138 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_137 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_136 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_135 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_134 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_133 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_132 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_131 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_130 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_129 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_128 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_127 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_126 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_125 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_124 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_123 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_122 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_121 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_120 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_119 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_118 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_117 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_116 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_115 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_114 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_113 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_112 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_111 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_110 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_109 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_108 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_107 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_106 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_105 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_104 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_103 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_102 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_101 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_100 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_99 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_98 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_97 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_96 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_95 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_94 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_93 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_92 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_91 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_90 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_89 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_88 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_87 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_86 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_85 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_84 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_83 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_82 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_81 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_80 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_79 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_78 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_77 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_76 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_75 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_74 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_73 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_72 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_71 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_70 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(81);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_69 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(82);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_68 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(83);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_67 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(84);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_66 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(85);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_65 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(86);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_64 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(87);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_63 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(88);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_62 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(89);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_61 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(90);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_60 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_59 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_58 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_57 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_56 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_55 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_54 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_53 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_52 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_51 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_50 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_49 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_48 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_47 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_46 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_45 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_44 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_43 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_42 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_41 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_40 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_39 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_38 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_37 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_36 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_35 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_34 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_33 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_32 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_31 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_30 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_29 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_28 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_27 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_26 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_25 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_24 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_23 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_22 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_21 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_20 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_19 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_18 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_17 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_16 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_15 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_14 = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_13 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(91);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_12 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(92);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_11 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(93);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_10 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(94);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_9 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(95);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_8 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(96);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_7 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(97);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_6 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(98);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_5 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(99);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_4 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(100);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_3 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(101);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_2 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(102);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_1 = function() {
	this.initialize(ss["anim htlm 2_atlas_2"]);
	this.gotoAndStop(103);
}).prototype = p = new cjs.Sprite();



(lib.Canardbleu = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.Canardjaune = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.Canardrose = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.Canardrouge = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.cible = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();



(lib.ciblepngcopy = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(81);
}).prototype = p = new cjs.Sprite();



(lib.marshlandscapeillustrationvector = function() {
	this.initialize(ss["anim htlm 2_atlas_"]);
	this.gotoAndStop(82);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbole7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Calque_1
	this.instance = new lib.ciblepngcopy();
	this.instance.setTransform(0,0,0.2969,0.2969);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbole7, new cjs.Rectangle(0,0,109.3,172.2), null);


(lib.Symbole6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Calque_1
	this.instance = new lib.Canardjaune();
	this.instance.setTransform(0,0,0.3756,0.3756);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbole6, new cjs.Rectangle(0,0,138.2,217.9), null);


(lib.Symbole5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Calque_1
	this.instance = new lib.cible();
	this.instance.setTransform(0,0,0.2677,0.2677);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbole5, new cjs.Rectangle(0,0,98.5,155.3), null);


(lib.Symbole4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Calque_1
	this.instance = new lib.Canardbleu();
	this.instance.setTransform(0,0,0.3776,0.3776);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbole4, new cjs.Rectangle(0,0,139,219), null);


(lib.Symbole3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Calque_1
	this.instance = new lib.Canardrouge();
	this.instance.setTransform(0,0,0.376,0.376);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbole3, new cjs.Rectangle(0,0,138.4,218.1), null);


(lib.Symbole2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Calque_1
	this.instance = new lib.Canardrose();
	this.instance.setTransform(0,0,0.3779,0.3779);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbole2, new cjs.Rectangle(0,0,139.1,219.2), null);


// stage content:
(lib.animhtlm = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		playSound("GAMEBOYADVANCEADVANCESPMICROStartupSound");
	}
	this.frame_120 = function() {
		playSound("podcastmúsicadefondo");
	}
	this.frame_899 = function() {
		playSound("_0438");
	}
	this.frame_1259 = function() {
		playSound("_0438mp3copy");
	}
	this.frame_1679 = function() {
		playSound("podcastmúsicadefondo");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(120).call(this.frame_120).wait(779).call(this.frame_899).wait(360).call(this.frame_1259).wait(420).call(this.frame_1679).wait(1));

	// P
	this.text = new cjs.Text("P", "85px 'Impact'");
	this.text.lineHeight = 104;
	this.text.parent = this;
	this.text.setTransform(610.05,341.1,0.5736,0.5736,-90);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(2).to({scaleX:0.5735,scaleY:0.5735,x:610},0).wait(10).to({scaleX:0.4701,scaleY:0.4701,x:611.45,y:347.6},0).wait(1).to({scaleX:0.4813,scaleY:0.4813,rotation:-88.0435,x:604.8876,y:342.2946},0).wait(1).to({scaleX:0.4924,scaleY:0.4924,rotation:-86.087,x:598.3406,y:336.9389},0).wait(1).to({scaleX:0.5035,scaleY:0.5035,rotation:-84.1304,x:591.8113,y:331.5331},0).wait(1).to({scaleX:0.5147,scaleY:0.5147,rotation:-82.1739,x:585.3022,y:326.0776},0).wait(1).to({scaleX:0.5258,scaleY:0.5258,rotation:-80.2174,x:578.8156,y:320.5731},0).wait(1).to({scaleX:0.5369,scaleY:0.5369,rotation:-78.2609,x:572.3539,y:315.0202},0).wait(1).to({scaleX:0.5481,scaleY:0.5481,rotation:-76.3043,x:565.9195,y:309.4196},0).wait(1).to({scaleX:0.5592,scaleY:0.5592,rotation:-74.3478,x:559.5146,y:303.7722},0).wait(1).to({scaleX:0.5703,scaleY:0.5703,rotation:-72.3913,x:553.1417,y:298.079},0).wait(1).to({scaleX:0.5814,scaleY:0.5814,rotation:-70.4348,x:546.8028,y:292.341},0).wait(1).to({scaleX:0.5926,scaleY:0.5926,rotation:-68.4783,x:540.5004,y:286.5594},0).wait(1).to({scaleX:0.6037,scaleY:0.6037,rotation:-66.5217,x:534.2366,y:280.7354},0).wait(1).to({scaleX:0.6148,scaleY:0.6148,rotation:-64.5652,x:528.0134,y:274.8705},0).wait(1).to({scaleX:0.626,scaleY:0.626,rotation:-62.6087,x:521.8331,y:268.9661},0).wait(1).to({scaleX:0.6371,scaleY:0.6371,rotation:-60.6522,x:515.6977,y:263.0237},0).wait(1).to({scaleX:0.6482,scaleY:0.6482,rotation:-58.6957,x:509.6091,y:257.0451},0).wait(1).to({scaleX:0.6593,scaleY:0.6593,rotation:-56.7391,x:503.5692,y:251.0319},0).wait(1).to({scaleX:0.6705,scaleY:0.6705,rotation:-54.7826,x:497.58,y:244.986},0).wait(1).to({scaleX:0.6816,scaleY:0.6816,rotation:-52.8261,x:491.6433,y:238.9093},0).wait(1).to({scaleX:0.6927,scaleY:0.6927,rotation:-50.8696,x:485.7606,y:232.8038},0).wait(1).to({scaleX:0.7039,scaleY:0.7039,rotation:-48.913,x:479.9338,y:226.6716},0).wait(1).to({scaleX:0.715,scaleY:0.715,rotation:-46.9565,x:474.1642,y:220.5149},0).wait(1).to({scaleX:0.7261,scaleY:0.7261,rotation:-45,x:468.4535,y:214.3358},0).wait(1).to({scaleX:0.7372,scaleY:0.7372,rotation:-43.0435,x:462.8031,y:208.1368},0).wait(1).to({scaleX:0.7484,scaleY:0.7484,rotation:-41.087,x:457.2141,y:201.9202},0).wait(1).to({scaleX:0.7595,scaleY:0.7595,rotation:-39.1304,x:451.6878,y:195.6883},0).wait(1).to({scaleX:0.7706,scaleY:0.7706,rotation:-37.1739,x:446.2254,y:189.4439},0).wait(1).to({scaleX:0.7818,scaleY:0.7818,rotation:-35.2174,x:440.8278,y:183.1893},0).wait(1).to({scaleX:0.7929,scaleY:0.7929,rotation:-33.2609,x:435.4959,y:176.9272},0).wait(1).to({scaleX:0.804,scaleY:0.804,rotation:-31.3043,x:430.2307,y:170.6603},0).wait(1).to({scaleX:0.8151,scaleY:0.8151,rotation:-29.3478,x:425.0327,y:164.3913},0).wait(1).to({scaleX:0.8263,scaleY:0.8263,rotation:-27.3913,x:419.9025,y:158.123},0).wait(1).to({scaleX:0.8374,scaleY:0.8374,rotation:-25.4348,x:414.8407,y:151.8581},0).wait(1).to({scaleX:0.8485,scaleY:0.8485,rotation:-23.4783,x:409.8476,y:145.5995},0).wait(1).to({scaleX:0.8597,scaleY:0.8597,rotation:-21.5217,x:404.9234,y:139.35},0).wait(1).to({scaleX:0.8708,scaleY:0.8708,rotation:-19.5652,x:400.0684,y:133.1125},0).wait(1).to({scaleX:0.8819,scaleY:0.8819,rotation:-17.6087,x:395.2825,y:126.8899},0).wait(1).to({scaleX:0.8931,scaleY:0.8931,rotation:-15.6522,x:390.5656,y:120.6851},0).wait(1).to({scaleX:0.9042,scaleY:0.9042,rotation:-13.6957,x:385.9176,y:114.501},0).wait(1).to({scaleX:0.9153,scaleY:0.9153,rotation:-11.7391,x:381.3381,y:108.3406},0).wait(1).to({scaleX:0.9264,scaleY:0.9264,rotation:-9.7826,x:376.8266,y:102.2069},0).wait(1).to({scaleX:0.9376,scaleY:0.9376,rotation:-7.8261,x:372.3826,y:96.1026},0).wait(1).to({scaleX:0.9487,scaleY:0.9487,rotation:-5.8696,x:368.0054,y:90.0308},0).wait(1).to({scaleX:0.9598,scaleY:0.9598,rotation:-3.913,x:363.6941,y:83.9943},0).wait(1).to({scaleX:0.971,scaleY:0.971,rotation:-1.9565,x:359.4479,y:77.9961},0).wait(1).to({scaleX:0.9821,scaleY:0.9821,rotation:0,x:355.2656,y:72.0389},0).wait(61).to({_off:true},1).wait(1560));

	// R
	this.instance = new lib.CachedBmp_1();
	this.instance.setTransform(362.5,357.95,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_2();
	this.instance_1.setTransform(362.5,357.95,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_3();
	this.instance_2.setTransform(362.5,357.95,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_4();
	this.instance_3.setTransform(362.5,357.95,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_5();
	this.instance_4.setTransform(362.5,357.95,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_6();
	this.instance_5.setTransform(362.5,357.95,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_7();
	this.instance_6.setTransform(362.5,357.95,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_8();
	this.instance_7.setTransform(357.75,343.4,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_9();
	this.instance_8.setTransform(353.05,328.75,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_10();
	this.instance_9.setTransform(348.4,314.15,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_11();
	this.instance_10.setTransform(343.95,299.5,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_12();
	this.instance_11.setTransform(339.65,284.8,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_13();
	this.instance_12.setTransform(335.45,270.25,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_14();
	this.instance_13.setTransform(331.45,255.8,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_15();
	this.instance_14.setTransform(327.55,241.45,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_16();
	this.instance_15.setTransform(323.95,227.2,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_17();
	this.instance_16.setTransform(320.6,213.05,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_18();
	this.instance_17.setTransform(317.4,199.2,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_19();
	this.instance_18.setTransform(314.45,185.45,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_20();
	this.instance_19.setTransform(311.8,172.05,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_21();
	this.instance_20.setTransform(309.5,158.8,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_22();
	this.instance_21.setTransform(307.4,145.8,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_23();
	this.instance_22.setTransform(305.55,133.1,0.5,0.5);

	this.instance_23 = new lib.CachedBmp_24();
	this.instance_23.setTransform(304.05,120.65,0.5,0.5);

	this.instance_24 = new lib.CachedBmp_25();
	this.instance_24.setTransform(302.75,108.55,0.5,0.5);

	this.instance_25 = new lib.CachedBmp_26();
	this.instance_25.setTransform(301.8,96.8,0.5,0.5);

	this.instance_26 = new lib.CachedBmp_27();
	this.instance_26.setTransform(301.25,85.35,0.5,0.5);

	this.instance_27 = new lib.CachedBmp_28();
	this.instance_27.setTransform(300.85,74.3,0.5,0.5);

	this.instance_28 = new lib.CachedBmp_29();
	this.instance_28.setTransform(300.7,63.5,0.5,0.5);

	this.instance_29 = new lib.CachedBmp_30();
	this.instance_29.setTransform(300.95,53.05,0.5,0.5);

	this.instance_30 = new lib.CachedBmp_31();
	this.instance_30.setTransform(300.95,53.05,0.5,0.5);

	this.instance_31 = new lib.CachedBmp_32();
	this.instance_31.setTransform(300.95,53.05,0.5,0.5);

	this.instance_32 = new lib.CachedBmp_33();
	this.instance_32.setTransform(300.95,53.05,0.5,0.5);

	this.instance_33 = new lib.CachedBmp_34();
	this.instance_33.setTransform(300.95,53.05,0.5,0.5);

	this.instance_34 = new lib.CachedBmp_35();
	this.instance_34.setTransform(300.95,53.05,0.5,0.5);

	this.instance_35 = new lib.CachedBmp_36();
	this.instance_35.setTransform(300.95,53.05,0.5,0.5);

	this.instance_36 = new lib.CachedBmp_37();
	this.instance_36.setTransform(300.95,53.05,0.5,0.5);

	this.instance_37 = new lib.CachedBmp_38();
	this.instance_37.setTransform(300.95,53.05,0.5,0.5);

	this.instance_38 = new lib.CachedBmp_39();
	this.instance_38.setTransform(300.95,53.05,0.5,0.5);

	this.instance_39 = new lib.CachedBmp_40();
	this.instance_39.setTransform(300.95,53.05,0.5,0.5);

	this.instance_40 = new lib.CachedBmp_41();
	this.instance_40.setTransform(300.95,53.05,0.5,0.5);

	this.instance_41 = new lib.CachedBmp_42();
	this.instance_41.setTransform(300.95,53.05,0.5,0.5);

	this.instance_42 = new lib.CachedBmp_43();
	this.instance_42.setTransform(300.95,53.05,0.5,0.5);

	this.instance_43 = new lib.CachedBmp_44();
	this.instance_43.setTransform(300.95,53.05,0.5,0.5);

	this.instance_44 = new lib.CachedBmp_45();
	this.instance_44.setTransform(300.95,53.05,0.5,0.5);

	this.instance_45 = new lib.CachedBmp_46();
	this.instance_45.setTransform(300.95,53.05,0.5,0.5);

	this.instance_46 = new lib.CachedBmp_47();
	this.instance_46.setTransform(300.95,53.05,0.5,0.5);

	this.instance_47 = new lib.CachedBmp_48();
	this.instance_47.setTransform(300.95,53.05,0.5,0.5);

	this.instance_48 = new lib.CachedBmp_49();
	this.instance_48.setTransform(300.95,53.05,0.5,0.5);

	this.instance_49 = new lib.CachedBmp_50();
	this.instance_49.setTransform(300.95,53.05,0.5,0.5);

	this.instance_50 = new lib.CachedBmp_51();
	this.instance_50.setTransform(300.95,53.05,0.5,0.5);

	this.instance_51 = new lib.CachedBmp_52();
	this.instance_51.setTransform(300.95,53.05,0.5,0.5);

	this.instance_52 = new lib.CachedBmp_53();
	this.instance_52.setTransform(300.95,53.05,0.5,0.5);

	this.instance_53 = new lib.CachedBmp_54();
	this.instance_53.setTransform(300.95,53.05,0.5,0.5);

	this.instance_54 = new lib.CachedBmp_55();
	this.instance_54.setTransform(300.95,53.05,0.5,0.5);

	this.instance_55 = new lib.CachedBmp_56();
	this.instance_55.setTransform(300.95,53.05,0.5,0.5);

	this.instance_56 = new lib.CachedBmp_57();
	this.instance_56.setTransform(300.95,53.05,0.5,0.5);

	this.instance_57 = new lib.CachedBmp_58();
	this.instance_57.setTransform(300.95,53.05,0.5,0.5);

	this.instance_58 = new lib.CachedBmp_59();
	this.instance_58.setTransform(300.95,53.05,0.5,0.5);

	this.instance_59 = new lib.CachedBmp_60();
	this.instance_59.setTransform(300.95,53.05,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).to({state:[{t:this.instance_8}]},2).to({state:[{t:this.instance_9}]},2).to({state:[{t:this.instance_10}]},2).to({state:[{t:this.instance_11}]},2).to({state:[{t:this.instance_12}]},2).to({state:[{t:this.instance_13}]},2).to({state:[{t:this.instance_14}]},2).to({state:[{t:this.instance_15}]},2).to({state:[{t:this.instance_16}]},2).to({state:[{t:this.instance_17}]},2).to({state:[{t:this.instance_18}]},2).to({state:[{t:this.instance_19}]},2).to({state:[{t:this.instance_20}]},2).to({state:[{t:this.instance_21}]},2).to({state:[{t:this.instance_22}]},2).to({state:[{t:this.instance_23}]},2).to({state:[{t:this.instance_24}]},2).to({state:[{t:this.instance_25}]},2).to({state:[{t:this.instance_26}]},2).to({state:[{t:this.instance_27}]},2).to({state:[{t:this.instance_28}]},2).to({state:[{t:this.instance_29}]},2).to({state:[{t:this.instance_30}]},2).to({state:[{t:this.instance_31}]},2).to({state:[{t:this.instance_32}]},2).to({state:[{t:this.instance_33}]},2).to({state:[{t:this.instance_34}]},2).to({state:[{t:this.instance_35}]},2).to({state:[{t:this.instance_36}]},2).to({state:[{t:this.instance_37}]},2).to({state:[{t:this.instance_38}]},2).to({state:[{t:this.instance_39}]},2).to({state:[{t:this.instance_40}]},2).to({state:[{t:this.instance_41}]},2).to({state:[{t:this.instance_42}]},2).to({state:[{t:this.instance_43}]},2).to({state:[{t:this.instance_44}]},2).to({state:[{t:this.instance_45}]},2).to({state:[{t:this.instance_46}]},2).to({state:[{t:this.instance_47}]},2).to({state:[{t:this.instance_48}]},2).to({state:[{t:this.instance_49}]},2).to({state:[{t:this.instance_50}]},2).to({state:[{t:this.instance_51}]},2).to({state:[{t:this.instance_52}]},2).to({state:[{t:this.instance_53}]},2).to({state:[{t:this.instance_54}]},2).to({state:[{t:this.instance_55}]},2).to({state:[{t:this.instance_56}]},2).to({state:[{t:this.instance_57}]},2).to({state:[{t:this.instance_58}]},2).to({state:[{t:this.instance_59}]},2).to({state:[]},2).wait(1560));

	// O
	this.instance_60 = new lib.CachedBmp_61();
	this.instance_60.setTransform(162.55,365.95,0.5,0.5);

	this.instance_61 = new lib.CachedBmp_62();
	this.instance_61.setTransform(162.55,365.95,0.5,0.5);

	this.instance_62 = new lib.CachedBmp_63();
	this.instance_62.setTransform(162.55,365.95,0.5,0.5);

	this.instance_63 = new lib.CachedBmp_64();
	this.instance_63.setTransform(162.55,365.95,0.5,0.5);

	this.instance_64 = new lib.CachedBmp_65();
	this.instance_64.setTransform(162.55,365.95,0.5,0.5);

	this.instance_65 = new lib.CachedBmp_66();
	this.instance_65.setTransform(162.55,365.95,0.5,0.5);

	this.instance_66 = new lib.CachedBmp_67();
	this.instance_66.setTransform(162.55,365.95,0.5,0.5);

	this.instance_67 = new lib.CachedBmp_68();
	this.instance_67.setTransform(164.4,351.8,0.5,0.5);

	this.instance_68 = new lib.CachedBmp_69();
	this.instance_68.setTransform(166.25,337.55,0.5,0.5);

	this.instance_69 = new lib.CachedBmp_70();
	this.instance_69.setTransform(168.3,323.3,0.5,0.5);

	this.instance_70 = new lib.CachedBmp_71();
	this.instance_70.setTransform(170.4,308.9,0.5,0.5);

	this.instance_71 = new lib.CachedBmp_72();
	this.instance_71.setTransform(172.55,294.5,0.5,0.5);

	this.instance_72 = new lib.CachedBmp_73();
	this.instance_72.setTransform(175,280.05,0.5,0.5);

	this.instance_73 = new lib.CachedBmp_74();
	this.instance_73.setTransform(177.55,265.65,0.5,0.5);

	this.instance_74 = new lib.CachedBmp_75();
	this.instance_74.setTransform(180.3,251.3,0.5,0.5);

	this.instance_75 = new lib.CachedBmp_76();
	this.instance_75.setTransform(183.25,236.95,0.5,0.5);

	this.instance_76 = new lib.CachedBmp_77();
	this.instance_76.setTransform(186.4,222.8,0.5,0.5);

	this.instance_77 = new lib.CachedBmp_78();
	this.instance_77.setTransform(189.85,208.65,0.5,0.5);

	this.instance_78 = new lib.CachedBmp_79();
	this.instance_78.setTransform(193.5,194.6,0.5,0.5);

	this.instance_79 = new lib.CachedBmp_80();
	this.instance_79.setTransform(197.45,180.7,0.5,0.5);

	this.instance_80 = new lib.CachedBmp_81();
	this.instance_80.setTransform(201.65,167,0.5,0.5);

	this.instance_81 = new lib.CachedBmp_82();
	this.instance_81.setTransform(206.15,153.55,0.5,0.5);

	this.instance_82 = new lib.CachedBmp_83();
	this.instance_82.setTransform(210.9,140.15,0.5,0.5);

	this.instance_83 = new lib.CachedBmp_84();
	this.instance_83.setTransform(216,127.05,0.5,0.5);

	this.instance_84 = new lib.CachedBmp_85();
	this.instance_84.setTransform(221.45,114.15,0.5,0.5);

	this.instance_85 = new lib.CachedBmp_86();
	this.instance_85.setTransform(227.15,101.6,0.5,0.5);

	this.instance_86 = new lib.CachedBmp_87();
	this.instance_86.setTransform(233.15,89.35,0.5,0.5);

	this.instance_87 = new lib.CachedBmp_88();
	this.instance_87.setTransform(239.5,77.25,0.5,0.5);

	this.instance_88 = new lib.CachedBmp_89();
	this.instance_88.setTransform(246.1,65.55,0.5,0.5);

	this.instance_89 = new lib.CachedBmp_90();
	this.instance_89.setTransform(253.05,54.15,0.5,0.5);

	this.instance_90 = new lib.CachedBmp_91();
	this.instance_90.setTransform(253.05,54.15,0.5,0.5);

	this.instance_91 = new lib.CachedBmp_92();
	this.instance_91.setTransform(253.05,54.15,0.5,0.5);

	this.instance_92 = new lib.CachedBmp_93();
	this.instance_92.setTransform(253.05,54.15,0.5,0.5);

	this.instance_93 = new lib.CachedBmp_94();
	this.instance_93.setTransform(253.05,54.15,0.5,0.5);

	this.instance_94 = new lib.CachedBmp_95();
	this.instance_94.setTransform(253.05,54.15,0.5,0.5);

	this.instance_95 = new lib.CachedBmp_96();
	this.instance_95.setTransform(253.05,54.15,0.5,0.5);

	this.instance_96 = new lib.CachedBmp_97();
	this.instance_96.setTransform(253.05,54.15,0.5,0.5);

	this.instance_97 = new lib.CachedBmp_98();
	this.instance_97.setTransform(253.05,54.15,0.5,0.5);

	this.instance_98 = new lib.CachedBmp_99();
	this.instance_98.setTransform(253.05,54.15,0.5,0.5);

	this.instance_99 = new lib.CachedBmp_100();
	this.instance_99.setTransform(253.05,54.15,0.5,0.5);

	this.instance_100 = new lib.CachedBmp_101();
	this.instance_100.setTransform(253.05,54.15,0.5,0.5);

	this.instance_101 = new lib.CachedBmp_102();
	this.instance_101.setTransform(253.05,54.15,0.5,0.5);

	this.instance_102 = new lib.CachedBmp_103();
	this.instance_102.setTransform(253.05,54.15,0.5,0.5);

	this.instance_103 = new lib.CachedBmp_104();
	this.instance_103.setTransform(253.05,54.15,0.5,0.5);

	this.instance_104 = new lib.CachedBmp_105();
	this.instance_104.setTransform(253.05,54.15,0.5,0.5);

	this.instance_105 = new lib.CachedBmp_106();
	this.instance_105.setTransform(253.05,54.15,0.5,0.5);

	this.instance_106 = new lib.CachedBmp_107();
	this.instance_106.setTransform(253.05,54.15,0.5,0.5);

	this.instance_107 = new lib.CachedBmp_108();
	this.instance_107.setTransform(253.05,54.15,0.5,0.5);

	this.instance_108 = new lib.CachedBmp_109();
	this.instance_108.setTransform(253.05,54.15,0.5,0.5);

	this.instance_109 = new lib.CachedBmp_110();
	this.instance_109.setTransform(253.05,54.15,0.5,0.5);

	this.instance_110 = new lib.CachedBmp_111();
	this.instance_110.setTransform(253.05,54.15,0.5,0.5);

	this.instance_111 = new lib.CachedBmp_112();
	this.instance_111.setTransform(253.05,54.15,0.5,0.5);

	this.instance_112 = new lib.CachedBmp_113();
	this.instance_112.setTransform(253.05,54.15,0.5,0.5);

	this.instance_113 = new lib.CachedBmp_114();
	this.instance_113.setTransform(253.05,54.15,0.5,0.5);

	this.instance_114 = new lib.CachedBmp_115();
	this.instance_114.setTransform(253.05,54.15,0.5,0.5);

	this.instance_115 = new lib.CachedBmp_116();
	this.instance_115.setTransform(253.05,54.15,0.5,0.5);

	this.instance_116 = new lib.CachedBmp_117();
	this.instance_116.setTransform(253.05,54.15,0.5,0.5);

	this.instance_117 = new lib.CachedBmp_118();
	this.instance_117.setTransform(253.05,54.15,0.5,0.5);

	this.instance_118 = new lib.CachedBmp_119();
	this.instance_118.setTransform(253.05,54.15,0.5,0.5);

	this.instance_119 = new lib.CachedBmp_120();
	this.instance_119.setTransform(253.05,54.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_60}]}).to({state:[{t:this.instance_61}]},2).to({state:[{t:this.instance_62}]},2).to({state:[{t:this.instance_63}]},2).to({state:[{t:this.instance_64}]},2).to({state:[{t:this.instance_65}]},2).to({state:[{t:this.instance_66}]},2).to({state:[{t:this.instance_67}]},2).to({state:[{t:this.instance_68}]},2).to({state:[{t:this.instance_69}]},2).to({state:[{t:this.instance_70}]},2).to({state:[{t:this.instance_71}]},2).to({state:[{t:this.instance_72}]},2).to({state:[{t:this.instance_73}]},2).to({state:[{t:this.instance_74}]},2).to({state:[{t:this.instance_75}]},2).to({state:[{t:this.instance_76}]},2).to({state:[{t:this.instance_77}]},2).to({state:[{t:this.instance_78}]},2).to({state:[{t:this.instance_79}]},2).to({state:[{t:this.instance_80}]},2).to({state:[{t:this.instance_81}]},2).to({state:[{t:this.instance_82}]},2).to({state:[{t:this.instance_83}]},2).to({state:[{t:this.instance_84}]},2).to({state:[{t:this.instance_85}]},2).to({state:[{t:this.instance_86}]},2).to({state:[{t:this.instance_87}]},2).to({state:[{t:this.instance_88}]},2).to({state:[{t:this.instance_89}]},2).to({state:[{t:this.instance_90}]},2).to({state:[{t:this.instance_91}]},2).to({state:[{t:this.instance_92}]},2).to({state:[{t:this.instance_93}]},2).to({state:[{t:this.instance_94}]},2).to({state:[{t:this.instance_95}]},2).to({state:[{t:this.instance_96}]},2).to({state:[{t:this.instance_97}]},2).to({state:[{t:this.instance_98}]},2).to({state:[{t:this.instance_99}]},2).to({state:[{t:this.instance_100}]},2).to({state:[{t:this.instance_101}]},2).to({state:[{t:this.instance_102}]},2).to({state:[{t:this.instance_103}]},2).to({state:[{t:this.instance_104}]},2).to({state:[{t:this.instance_105}]},2).to({state:[{t:this.instance_106}]},2).to({state:[{t:this.instance_107}]},2).to({state:[{t:this.instance_108}]},2).to({state:[{t:this.instance_109}]},2).to({state:[{t:this.instance_110}]},2).to({state:[{t:this.instance_111}]},2).to({state:[{t:this.instance_112}]},2).to({state:[{t:this.instance_113}]},2).to({state:[{t:this.instance_114}]},2).to({state:[{t:this.instance_115}]},2).to({state:[{t:this.instance_116}]},2).to({state:[{t:this.instance_117}]},2).to({state:[{t:this.instance_118}]},2).to({state:[{t:this.instance_119}]},2).to({state:[]},2).wait(1560));

	// C
	this.instance_120 = new lib.CachedBmp_121();
	this.instance_120.setTransform(-61.25,323.45,0.5,0.5);

	this.instance_121 = new lib.CachedBmp_122();
	this.instance_121.setTransform(-61.2,323.4,0.5,0.5);

	this.instance_122 = new lib.CachedBmp_123();
	this.instance_122.setTransform(-61.2,323.4,0.5,0.5);

	this.instance_123 = new lib.CachedBmp_124();
	this.instance_123.setTransform(-61.2,323.4,0.5,0.5);

	this.instance_124 = new lib.CachedBmp_125();
	this.instance_124.setTransform(-61.2,323.4,0.5,0.5);

	this.instance_125 = new lib.CachedBmp_126();
	this.instance_125.setTransform(-61.2,323.4,0.5,0.5);

	this.instance_126 = new lib.CachedBmp_127();
	this.instance_126.setTransform(-61.2,323.4,0.5,0.5);

	this.instance_127 = new lib.CachedBmp_128();
	this.instance_127.setTransform(-51.75,311.1,0.5,0.5);

	this.instance_128 = new lib.CachedBmp_129();
	this.instance_128.setTransform(-42.05,298.65,0.5,0.5);

	this.instance_129 = new lib.CachedBmp_130();
	this.instance_129.setTransform(-32.4,286.05,0.5,0.5);

	this.instance_130 = new lib.CachedBmp_131();
	this.instance_130.setTransform(-22.5,273.5,0.5,0.5);

	this.instance_131 = new lib.CachedBmp_132();
	this.instance_131.setTransform(-12.55,260.85,0.5,0.5);

	this.instance_132 = new lib.CachedBmp_133();
	this.instance_132.setTransform(-2.45,248.3,0.5,0.5);

	this.instance_133 = new lib.CachedBmp_134();
	this.instance_133.setTransform(7.8,235.65,0.5,0.5);

	this.instance_134 = new lib.CachedBmp_135();
	this.instance_134.setTransform(18.3,223.1,0.5,0.5);

	this.instance_135 = new lib.CachedBmp_136();
	this.instance_135.setTransform(28.95,210.55,0.5,0.5);

	this.instance_136 = new lib.CachedBmp_137();
	this.instance_136.setTransform(39.9,198.1,0.5,0.5);

	this.instance_137 = new lib.CachedBmp_138();
	this.instance_137.setTransform(51.05,185.75,0.5,0.5);

	this.instance_138 = new lib.CachedBmp_139();
	this.instance_138.setTransform(62.45,173.55,0.5,0.5);

	this.instance_139 = new lib.CachedBmp_140();
	this.instance_139.setTransform(74.05,161.5,0.5,0.5);

	this.instance_140 = new lib.CachedBmp_141();
	this.instance_140.setTransform(86,149.5,0.5,0.5);

	this.instance_141 = new lib.CachedBmp_142();
	this.instance_141.setTransform(98.2,137.85,0.5,0.5);

	this.instance_142 = new lib.CachedBmp_143();
	this.instance_142.setTransform(110.7,126.3,0.5,0.5);

	this.instance_143 = new lib.CachedBmp_144();
	this.instance_143.setTransform(123.45,115.1,0.5,0.5);

	this.instance_144 = new lib.CachedBmp_145();
	this.instance_144.setTransform(136.55,104,0.5,0.5);

	this.instance_145 = new lib.CachedBmp_146();
	this.instance_145.setTransform(149.9,93.25,0.5,0.5);

	this.instance_146 = new lib.CachedBmp_147();
	this.instance_146.setTransform(163.6,82.8,0.5,0.5);

	this.instance_147 = new lib.CachedBmp_148();
	this.instance_147.setTransform(177.6,72.6,0.5,0.5);

	this.instance_148 = new lib.CachedBmp_149();
	this.instance_148.setTransform(191.8,62.7,0.5,0.5);

	this.instance_149 = new lib.CachedBmp_150();
	this.instance_149.setTransform(206.4,53,0.5,0.5);

	this.instance_150 = new lib.CachedBmp_151();
	this.instance_150.setTransform(206.4,53,0.5,0.5);

	this.instance_151 = new lib.CachedBmp_152();
	this.instance_151.setTransform(206.4,53,0.5,0.5);

	this.instance_152 = new lib.CachedBmp_153();
	this.instance_152.setTransform(206.4,53,0.5,0.5);

	this.instance_153 = new lib.CachedBmp_154();
	this.instance_153.setTransform(206.4,53,0.5,0.5);

	this.instance_154 = new lib.CachedBmp_155();
	this.instance_154.setTransform(206.4,53,0.5,0.5);

	this.instance_155 = new lib.CachedBmp_156();
	this.instance_155.setTransform(206.4,53,0.5,0.5);

	this.instance_156 = new lib.CachedBmp_157();
	this.instance_156.setTransform(206.4,53,0.5,0.5);

	this.instance_157 = new lib.CachedBmp_158();
	this.instance_157.setTransform(206.4,53,0.5,0.5);

	this.instance_158 = new lib.CachedBmp_159();
	this.instance_158.setTransform(206.4,53,0.5,0.5);

	this.instance_159 = new lib.CachedBmp_160();
	this.instance_159.setTransform(206.4,53,0.5,0.5);

	this.instance_160 = new lib.CachedBmp_161();
	this.instance_160.setTransform(206.4,53,0.5,0.5);

	this.instance_161 = new lib.CachedBmp_162();
	this.instance_161.setTransform(206.4,53,0.5,0.5);

	this.instance_162 = new lib.CachedBmp_163();
	this.instance_162.setTransform(206.4,53,0.5,0.5);

	this.instance_163 = new lib.CachedBmp_164();
	this.instance_163.setTransform(206.4,53,0.5,0.5);

	this.instance_164 = new lib.CachedBmp_165();
	this.instance_164.setTransform(206.4,53,0.5,0.5);

	this.instance_165 = new lib.CachedBmp_166();
	this.instance_165.setTransform(206.4,53,0.5,0.5);

	this.instance_166 = new lib.CachedBmp_167();
	this.instance_166.setTransform(206.4,53,0.5,0.5);

	this.instance_167 = new lib.CachedBmp_168();
	this.instance_167.setTransform(206.4,53,0.5,0.5);

	this.instance_168 = new lib.CachedBmp_169();
	this.instance_168.setTransform(206.4,53,0.5,0.5);

	this.instance_169 = new lib.CachedBmp_170();
	this.instance_169.setTransform(206.4,53,0.5,0.5);

	this.instance_170 = new lib.CachedBmp_171();
	this.instance_170.setTransform(206.4,53,0.5,0.5);

	this.instance_171 = new lib.CachedBmp_172();
	this.instance_171.setTransform(206.4,53,0.5,0.5);

	this.instance_172 = new lib.CachedBmp_173();
	this.instance_172.setTransform(206.4,53,0.5,0.5);

	this.instance_173 = new lib.CachedBmp_174();
	this.instance_173.setTransform(206.4,53,0.5,0.5);

	this.instance_174 = new lib.CachedBmp_175();
	this.instance_174.setTransform(206.4,53,0.5,0.5);

	this.instance_175 = new lib.CachedBmp_176();
	this.instance_175.setTransform(206.4,53,0.5,0.5);

	this.instance_176 = new lib.CachedBmp_177();
	this.instance_176.setTransform(206.4,53,0.5,0.5);

	this.instance_177 = new lib.CachedBmp_178();
	this.instance_177.setTransform(206.4,53,0.5,0.5);

	this.instance_178 = new lib.CachedBmp_179();
	this.instance_178.setTransform(206.4,53,0.5,0.5);

	this.instance_179 = new lib.CachedBmp_180();
	this.instance_179.setTransform(206.4,53,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_120}]}).to({state:[{t:this.instance_121}]},2).to({state:[{t:this.instance_122}]},2).to({state:[{t:this.instance_123}]},2).to({state:[{t:this.instance_124}]},2).to({state:[{t:this.instance_125}]},2).to({state:[{t:this.instance_126}]},2).to({state:[{t:this.instance_127}]},2).to({state:[{t:this.instance_128}]},2).to({state:[{t:this.instance_129}]},2).to({state:[{t:this.instance_130}]},2).to({state:[{t:this.instance_131}]},2).to({state:[{t:this.instance_132}]},2).to({state:[{t:this.instance_133}]},2).to({state:[{t:this.instance_134}]},2).to({state:[{t:this.instance_135}]},2).to({state:[{t:this.instance_136}]},2).to({state:[{t:this.instance_137}]},2).to({state:[{t:this.instance_138}]},2).to({state:[{t:this.instance_139}]},2).to({state:[{t:this.instance_140}]},2).to({state:[{t:this.instance_141}]},2).to({state:[{t:this.instance_142}]},2).to({state:[{t:this.instance_143}]},2).to({state:[{t:this.instance_144}]},2).to({state:[{t:this.instance_145}]},2).to({state:[{t:this.instance_146}]},2).to({state:[{t:this.instance_147}]},2).to({state:[{t:this.instance_148}]},2).to({state:[{t:this.instance_149}]},2).to({state:[{t:this.instance_150}]},2).to({state:[{t:this.instance_151}]},2).to({state:[{t:this.instance_152}]},2).to({state:[{t:this.instance_153}]},2).to({state:[{t:this.instance_154}]},2).to({state:[{t:this.instance_155}]},2).to({state:[{t:this.instance_156}]},2).to({state:[{t:this.instance_157}]},2).to({state:[{t:this.instance_158}]},2).to({state:[{t:this.instance_159}]},2).to({state:[{t:this.instance_160}]},2).to({state:[{t:this.instance_161}]},2).to({state:[{t:this.instance_162}]},2).to({state:[{t:this.instance_163}]},2).to({state:[{t:this.instance_164}]},2).to({state:[{t:this.instance_165}]},2).to({state:[{t:this.instance_166}]},2).to({state:[{t:this.instance_167}]},2).to({state:[{t:this.instance_168}]},2).to({state:[{t:this.instance_169}]},2).to({state:[{t:this.instance_170}]},2).to({state:[{t:this.instance_171}]},2).to({state:[{t:this.instance_172}]},2).to({state:[{t:this.instance_173}]},2).to({state:[{t:this.instance_174}]},2).to({state:[{t:this.instance_175}]},2).to({state:[{t:this.instance_176}]},2).to({state:[{t:this.instance_177}]},2).to({state:[{t:this.instance_178}]},2).to({state:[{t:this.instance_179}]},2).to({state:[]},2).wait(1560));

	// Calque_9
	this.text_1 = new cjs.Text("PRODUCTION", "45px 'Bradley Hand ITC'");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 58;
	this.text_1.lineWidth = 596;
	this.text_1.parent = this;
	this.text_1.setTransform(-198.95,144.3);

	this.timeline.addTween(cjs.Tween.get(this.text_1).wait(1).to({x:-198.8533},0).wait(1).to({x:-198.7567},0).wait(1).to({x:-198.66},0).wait(1).to({x:-198.5634},0).wait(1).to({x:-198.4667},0).wait(1).to({x:-198.3701},0).wait(1).to({x:-198.2734},0).wait(1).to({x:-198.1767},0).wait(1).to({x:-198.0801},0).wait(1).to({x:-197.9834},0).wait(1).to({x:-197.8868},0).wait(1).to({x:-197.7901},0).wait(1).to({x:-197.6934},0).wait(1).to({x:-197.5968},0).wait(1).to({x:-197.5001},0).wait(1).to({x:-197.4035},0).wait(1).to({x:-197.3068},0).wait(1).to({x:-197.2102},0).wait(1).to({x:-197.1135},0).wait(1).to({x:-197.0168},0).wait(1).to({x:-196.9202},0).wait(1).to({x:-196.8235},0).wait(1).to({x:-196.7269},0).wait(1).to({x:-196.6302},0).wait(1).to({x:-196.5335},0).wait(1).to({x:-196.4369},0).wait(1).to({x:-196.3402},0).wait(1).to({x:-196.2436},0).wait(1).to({x:-196.1469},0).wait(1).to({x:-196.0503},0).wait(1).to({x:-195.9536},0).wait(1).to({x:-195.8569},0).wait(1).to({x:-195.7603},0).wait(1).to({x:-195.6636},0).wait(1).to({x:-195.567},0).wait(1).to({x:-195.4703},0).wait(1).to({x:-195.3736},0).wait(1).to({x:-195.277},0).wait(1).to({x:-195.1803},0).wait(1).to({x:-195.0837},0).wait(1).to({x:-194.987},0).wait(1).to({x:-194.8904},0).wait(1).to({x:-194.7937},0).wait(1).to({x:-194.697},0).wait(1).to({x:-194.6004},0).wait(1).to({x:-194.5037},0).wait(1).to({x:-194.4071},0).wait(1).to({x:-194.3104},0).wait(1).to({x:-194.2137},0).wait(1).to({x:-194.1171},0).wait(1).to({x:-194.0204},0).wait(1).to({x:-193.9238},0).wait(1).to({x:-193.8271},0).wait(1).to({x:-193.7305},0).wait(1).to({x:-193.6338},0).wait(1).to({x:-193.5371},0).wait(1).to({x:-193.4405},0).wait(1).to({x:-193.3438},0).wait(1).to({x:-177.4295},0).wait(1).to({x:-161.5152},0).wait(1).to({x:-145.6009},0).wait(1).to({x:-129.6866},0).wait(1).to({x:-113.7722},0).wait(1).to({x:-97.8579},0).wait(1).to({x:-81.9436},0).wait(1).to({x:-66.0293},0).wait(1).to({x:-50.115},0).wait(1).to({x:-34.2007},0).wait(1).to({x:-18.2863},0).wait(1).to({x:-2.372},0).wait(1).to({x:13.5423},0).wait(1).to({x:29.4566},0).wait(1).to({x:45.3709},0).wait(1).to({x:61.2852},0).wait(1).to({x:77.1996},0).wait(1).to({x:93.1139},0).wait(1).to({x:109.0282},0).wait(1).to({x:124.9425},0).wait(1).to({x:140.8568},0).wait(1).to({x:156.7711},0).wait(1).to({x:172.6855},0).wait(1).to({x:188.5998},0).wait(1).to({x:204.5141},0).wait(1).to({x:220.4284},0).wait(1).to({x:236.3427},0).wait(1).to({x:252.257},0).wait(1).to({x:268.1714},0).wait(1).to({x:284.0857},0).wait(1).to({x:300},0).wait(30).to({_off:true},1).wait(1560));

	// Calque_12
	this.text_2 = new cjs.Text("Ces canards doivent traverser une petite partie\n du lac, mais celle-ci  est dangeureuse : \ndes étudiants veulent leur tirer dessus", "italic 30px 'Harlow Solid Italic'");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 40;
	this.text_2.lineWidth = 595;
	this.text_2.parent = this;
	this.text_2.setTransform(300.5,356.45);
	this.text_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_2).wait(120).to({_off:false},0).wait(1).to({y:354.4441},0).wait(1).to({y:352.4381},0).wait(1).to({y:350.4322},0).wait(1).to({y:348.4263},0).wait(1).to({y:346.4203},0).wait(1).to({y:344.4144},0).wait(1).to({y:342.4085},0).wait(1).to({y:340.4025},0).wait(1).to({y:338.3966},0).wait(1).to({y:336.3907},0).wait(1).to({y:334.3847},0).wait(1).to({y:332.3788},0).wait(1).to({y:330.3729},0).wait(1).to({y:328.3669},0).wait(1).to({y:326.361},0).wait(1).to({y:324.3551},0).wait(1).to({y:322.3492},0).wait(1).to({y:320.3432},0).wait(1).to({y:318.3373},0).wait(1).to({y:316.3314},0).wait(1).to({y:314.3254},0).wait(1).to({y:312.3195},0).wait(1).to({y:310.3136},0).wait(1).to({y:308.3076},0).wait(1).to({y:306.3017},0).wait(1).to({y:304.2958},0).wait(1).to({y:302.2898},0).wait(1).to({y:300.2839},0).wait(1).to({y:298.278},0).wait(1).to({y:296.272},0).wait(1).to({y:294.2661},0).wait(1).to({y:292.2602},0).wait(1).to({y:290.2542},0).wait(1).to({y:288.2483},0).wait(1).to({y:286.2424},0).wait(1).to({y:284.2364},0).wait(1).to({y:282.2305},0).wait(1).to({y:280.2246},0).wait(1).to({y:278.2186},0).wait(1).to({y:276.2127},0).wait(1).to({y:274.2068},0).wait(1).to({y:272.2008},0).wait(1).to({y:270.1949},0).wait(1).to({y:268.189},0).wait(1).to({y:266.1831},0).wait(1).to({y:264.1771},0).wait(1).to({y:262.1712},0).wait(1).to({y:260.1653},0).wait(1).to({y:258.1593},0).wait(1).to({y:256.1534},0).wait(1).to({y:254.1475},0).wait(1).to({y:252.1415},0).wait(1).to({y:250.1356},0).wait(1).to({y:248.1297},0).wait(1).to({y:246.1237},0).wait(1).to({y:244.1178},0).wait(1).to({y:242.1119},0).wait(1).to({y:240.1059},0).wait(1).to({y:238.1},0).wait(105).to({_off:true},1).wait(1395));

	// Calque_22
	this.instance_180 = new lib.Symbole5();
	this.instance_180.setTransform(348.3,-45.4,1,1,0,0,0,49.3,77.6);
	this.instance_180._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_180).wait(659).to({_off:false},0).wait(1).to({y:-43.25},0).wait(1).to({y:-41.15},0).wait(1).to({y:-39.05},0).wait(1).to({y:-36.95},0).wait(1).to({y:-34.85},0).wait(1).to({y:-32.75},0).wait(1).to({y:-30.6},0).wait(1).to({y:-28.5},0).wait(1).to({y:-26.4},0).wait(1).to({y:-24.3},0).wait(1).to({y:-22.2},0).wait(1).to({y:-20.1},0).wait(1).to({y:-17.95},0).wait(1).to({y:-15.85},0).wait(1).to({y:-13.75},0).wait(1).to({y:-11.65},0).wait(1).to({y:-9.55},0).wait(1).to({y:-7.45},0).wait(1).to({y:-5.35},0).wait(1).to({y:-3.2},0).wait(1).to({y:-1.1},0).wait(1).to({y:1},0).wait(1).to({y:3.1},0).wait(1).to({y:5.2},0).wait(1).to({y:7.3},0).wait(1).to({y:9.45},0).wait(1).to({y:11.55},0).wait(1).to({y:13.65},0).wait(1).to({y:15.75},0).wait(1).to({y:17.85},0).wait(1).to({y:19.95},0).wait(1).to({y:22.05},0).wait(1).to({y:24.2},0).wait(1).to({y:26.3},0).wait(1).to({y:28.4},0).wait(1).to({y:30.5},0).wait(1).to({y:32.6},0).wait(1).to({y:34.7},0).wait(1).to({y:36.85},0).wait(1).to({y:38.95},0).wait(1).to({y:41.05},0).wait(1).to({y:43.15},0).wait(1).to({y:45.25},0).wait(1).to({y:47.35},0).wait(1).to({y:49.5},0).wait(1).to({y:51.6},0).wait(1).to({y:53.7},0).wait(1).to({y:55.8},0).wait(1).to({y:57.9},0).wait(1).to({y:60},0).wait(1).to({y:62.1},0).wait(1).to({y:64.25},0).wait(1).to({y:66.35},0).wait(1).to({y:68.45},0).wait(1).to({y:70.55},0).wait(1).to({y:72.65},0).wait(1).to({y:74.75},0).wait(1).to({y:76.9},0).wait(1).to({y:78.95},0).wait(1).to({y:81.05},0).wait(1).to({y:83.15},0).wait(1).to({y:85.25},0).wait(1).to({y:87.35},0).wait(1).to({y:89.45},0).wait(1).to({y:91.6},0).wait(1).to({y:93.7},0).wait(1).to({y:95.8},0).wait(1).to({y:97.9},0).wait(1).to({y:100},0).wait(1).to({y:102.1},0).wait(1).to({y:104.25},0).wait(1).to({y:106.35},0).wait(1).to({y:108.45},0).wait(1).to({y:110.55},0).wait(1).to({y:112.65},0).wait(1).to({y:114.75},0).wait(1).to({y:116.9},0).wait(1).to({x:348.25},0).wait(2).to({x:348.2},0).wait(3).to({x:348.15},0).wait(2).to({x:348.1},0).wait(3).to({x:348.05},0).wait(2).to({x:348},0).wait(3).to({x:347.95},0).wait(2).to({x:347.9},0).wait(3).to({x:347.85},0).wait(2).to({x:347.8},0).wait(3).to({x:347.75},0).wait(2).to({x:347.7},0).wait(3).to({x:347.65},0).wait(2).to({x:347.6},0).wait(3).to({x:347.55},0).wait(3).to({x:347.5},0).wait(2).to({x:347.45},0).wait(3).to({x:347.4},0).wait(2).to({x:347.35},0).wait(3).to({x:347.3},0).wait(2).to({x:347.25},0).wait(3).to({x:347.2},0).wait(2).to({x:347.15},0).wait(3).to({x:347.1},0).wait(2).to({x:347.05},0).wait(3).to({x:347},0).wait(2).to({x:346.95},0).wait(3).to({x:346.9},0).wait(3).to({x:346.85},0).wait(2).to({x:346.8},0).wait(3).to({x:346.75},0).wait(2).to({x:346.7},0).wait(3).to({x:346.65},0).wait(2).to({x:346.6},0).wait(3).to({x:346.55},0).wait(2).to({x:346.5},0).wait(3).to({x:346.45},0).wait(2).to({x:346.4},0).wait(3).to({x:346.35},0).wait(2).to({x:346.3},0).wait(3).to({x:346.25},0).wait(91).to({_off:true},1).wait(750));

	// Calque_21
	this.text_3 = new cjs.Text("Un étudiant vise le canard rouge", "italic 30px 'Harlow Solid Italic'");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 40;
	this.text_3.lineWidth = 597;
	this.text_3.parent = this;
	this.text_3.setTransform(300.6,-37.45);
	this.text_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_3).wait(569).to({_off:false},0).wait(1).to({y:-35.7912},0).wait(1).to({y:-34.1325},0).wait(1).to({y:-32.4737},0).wait(1).to({y:-30.815},0).wait(1).to({y:-29.1562},0).wait(1).to({y:-27.4975},0).wait(1).to({y:-25.8387},0).wait(1).to({y:-24.18},0).wait(1).to({y:-22.5212},0).wait(1).to({y:-20.8625},0).wait(1).to({y:-19.2037},0).wait(1).to({y:-17.545},0).wait(1).to({y:-15.8862},0).wait(1).to({y:-14.2275},0).wait(1).to({y:-12.5687},0).wait(1).to({y:-10.91},0).wait(1).to({y:-9.2512},0).wait(1).to({y:-7.5925},0).wait(1).to({y:-5.9337},0).wait(1).to({y:-4.275},0).wait(1).to({y:-2.6162},0).wait(1).to({y:-0.9575},0).wait(1).to({y:0.7013},0).wait(1).to({y:2.36},0).wait(1).to({y:4.0188},0).wait(1).to({y:5.6775},0).wait(1).to({y:7.3363},0).wait(1).to({y:8.995},0).wait(1).to({y:10.6538},0).wait(1).to({y:12.3125},0).wait(1).to({y:13.9713},0).wait(1).to({y:15.63},0).wait(1).to({y:17.2888},0).wait(1).to({y:18.9475},0).wait(1).to({y:20.6063},0).wait(1).to({y:22.265},0).wait(1).to({y:23.9237},0).wait(1).to({y:25.5825},0).wait(1).to({y:27.2413},0).wait(1).to({y:28.9},0).wait(51).to({x:318.3283},0).wait(1).to({x:336.0567},0).wait(1).to({x:353.785},0).wait(1).to({x:371.5133},0).wait(1).to({x:389.2417},0).wait(1).to({x:406.97},0).wait(1).to({x:424.6983},0).wait(1).to({x:442.4267},0).wait(1).to({x:460.155},0).wait(1).to({x:477.8833},0).wait(1).to({x:495.6117},0).wait(1).to({x:513.34},0).wait(1).to({x:531.0683},0).wait(1).to({x:548.7967},0).wait(1).to({x:566.525},0).wait(1).to({x:584.2533},0).wait(1).to({x:601.9817},0).wait(1).to({x:619.71},0).wait(1).to({x:637.4383},0).wait(1).to({x:655.1667},0).wait(1).to({x:672.895},0).wait(1).to({x:690.6233},0).wait(1).to({x:708.3517},0).wait(1).to({x:726.08},0).wait(1).to({x:743.8083},0).wait(1).to({x:761.5367},0).wait(1).to({x:779.265},0).wait(1).to({x:796.9933},0).wait(1).to({x:814.7217},0).wait(1).to({x:832.45},0).to({_off:true},1).wait(990));

	// Calque_11
	this.text_4 = new cjs.Text("L'étrange migration des canards du lac\n de Louvain-la-Neuve a lieu tous les ans", "italic 30px 'Harlow Solid Italic'");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 40;
	this.text_4.lineWidth = 593;
	this.text_4.parent = this;
	this.text_4.setTransform(286.5,-79.8);

	this.timeline.addTween(cjs.Tween.get(this.text_4).wait(120).to({y:-75.7},0).wait(1).to({y:-72.3316},0).wait(1).to({y:-68.9632},0).wait(1).to({y:-65.5948},0).wait(1).to({y:-62.2264},0).wait(1).to({y:-58.8579},0).wait(1).to({y:-55.4895},0).wait(1).to({y:-52.1211},0).wait(1).to({y:-48.7527},0).wait(1).to({y:-45.3843},0).wait(1).to({y:-42.0159},0).wait(1).to({y:-38.6475},0).wait(1).to({y:-35.2791},0).wait(1).to({y:-31.9107},0).wait(1).to({y:-28.5423},0).wait(1).to({y:-25.1738},0).wait(1).to({y:-21.8054},0).wait(1).to({y:-18.437},0).wait(1).to({y:-15.0686},0).wait(1).to({y:-11.7002},0).wait(1).to({y:-8.3318},0).wait(1).to({y:-4.9634},0).wait(1).to({y:-1.595},0).wait(1).to({y:1.7734},0).wait(1).to({y:5.1418},0).wait(1).to({y:8.5103},0).wait(1).to({y:11.8787},0).wait(1).to({y:15.2471},0).wait(1).to({y:18.6155},0).wait(1).to({y:21.9839},0).wait(1).to({y:22.7244},0).wait(1).to({y:23.465},0).wait(1).to({y:24.2055},0).wait(1).to({y:24.946},0).wait(1).to({y:25.6866},0).wait(1).to({y:26.4271},0).wait(1).to({y:27.1677},0).wait(1).to({y:27.9082},0).wait(1).to({y:28.6487},0).wait(1).to({y:29.3893},0).wait(1).to({y:30.1298},0).wait(1).to({y:30.8703},0).wait(1).to({y:31.6109},0).wait(1).to({y:32.3514},0).wait(1).to({y:33.092},0).wait(1).to({y:33.8325},0).wait(1).to({y:34.573},0).wait(1).to({y:35.3136},0).wait(1).to({y:36.0541},0).wait(1).to({y:36.7946},0).wait(1).to({y:37.5352},0).wait(1).to({y:38.2757},0).wait(1).to({y:39.0162},0).wait(1).to({y:39.7568},0).wait(1).to({y:40.4973},0).wait(1).to({y:41.2379},0).wait(1).to({y:41.9784},0).wait(1).to({y:42.7189},0).wait(1).to({y:43.4595},0).wait(1).to({y:44.2},0).wait(105).to({_off:true},1).wait(1395));

	// Calque_13
	this.text_5 = new cjs.Text("Cette année, deux canards auront réussi\nla migration du lac de Louvain-la-Neuve.\n\nRendez-vous l'année prochaine assister \nà une nouvelle migration ! ", "italic 30px 'Harlow Solid Italic'");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 40;
	this.text_5.lineWidth = 529;
	this.text_5.parent = this;
	this.text_5.setTransform(841.4,325.65,0.2212,0.2212,180);
	this.text_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_5).wait(1469).to({_off:false},0).wait(1).to({scaleX:0.2318,scaleY:0.2318,rotation:178,x:836.2864,y:325.5658},0).wait(1).to({scaleX:0.2423,scaleY:0.2423,rotation:176,x:831.2274,y:325.4036},0).wait(1).to({scaleX:0.2529,scaleY:0.2529,rotation:174,x:826.3118,y:325.2621},0).wait(1).to({scaleX:0.2634,scaleY:0.2634,rotation:172,x:821.428,y:325.0405},0).wait(1).to({scaleX:0.274,scaleY:0.274,rotation:170,x:816.6644,y:324.7886},0).wait(1).to({scaleX:0.2845,scaleY:0.2845,rotation:168,x:811.9594,y:324.4566},0).wait(1).to({scaleX:0.295,scaleY:0.295,rotation:166,x:807.3513,y:324.0953},0).wait(1).to({scaleX:0.3056,scaleY:0.3056,rotation:164,x:802.7786,y:323.6562},0).wait(1).to({scaleX:0.3161,scaleY:0.3161,rotation:162,x:798.3296,y:323.1409},0).wait(1).to({scaleX:0.3267,scaleY:0.3267,rotation:160,x:793.8927,y:322.552},0).wait(1).to({scaleX:0.3372,scaleY:0.3372,rotation:158,x:789.5566,y:321.8923},0).wait(1).to({scaleX:0.3478,scaleY:0.3478,rotation:156,x:785.2599,y:321.1654},0).wait(1).to({scaleX:0.3583,scaleY:0.3583,rotation:154,x:781.0413,y:320.3751},0).wait(1).to({scaleX:0.3689,scaleY:0.3689,rotation:152,x:776.8898,y:319.4761},0).wait(1).to({scaleX:0.3794,scaleY:0.3794,rotation:150,x:772.7944,y:318.5233},0).wait(1).to({scaleX:0.39,scaleY:0.39,rotation:148,x:768.6944,y:317.4222},0).wait(1).to({scaleX:0.4005,scaleY:0.4005,rotation:146,x:764.6794,y:316.2789},0).wait(1).to({scaleX:0.4111,scaleY:0.4111,rotation:144,x:760.739,y:314.9998},0).wait(1).to({scaleX:0.4216,scaleY:0.4216,rotation:142,x:756.7632,y:313.6421},0).wait(1).to({scaleX:0.4322,scaleY:0.4322,rotation:140,x:752.8923,y:312.163},0).wait(1).to({scaleX:0.4427,scaleY:0.4427,rotation:138,x:749.0169,y:310.6206},0).wait(1).to({scaleX:0.4533,scaleY:0.4533,rotation:136,x:745.1279,y:308.9733},0).wait(1).to({scaleX:0.4638,scaleY:0.4638,rotation:134,x:741.3164,y:307.1797},0).wait(1).to({scaleX:0.4744,scaleY:0.4744,rotation:132,x:737.474,y:305.2993},0).wait(1).to({scaleX:0.4849,scaleY:0.4849,rotation:130,x:733.6428,y:303.2916},0).wait(1).to({scaleX:0.4955,scaleY:0.4955,rotation:128,x:729.8151,y:301.1666},0).wait(1).to({scaleX:0.506,scaleY:0.506,rotation:126,x:726.0336,y:298.9848},0).wait(1).to({scaleX:0.5166,scaleY:0.5166,rotation:124,x:722.1916,y:296.6069},0).wait(1).to({scaleX:0.5271,scaleY:0.5271,rotation:122,x:718.3327,y:294.1941},0).wait(1).to({scaleX:0.5377,scaleY:0.5377,rotation:120,x:714.501,y:291.6077},0).wait(1).to({scaleX:0.5482,scaleY:0.5482,rotation:118,x:710.6411,y:288.9596},0).wait(1).to({scaleX:0.5588,scaleY:0.5588,rotation:116,x:706.6981,y:286.1617},0).wait(1).to({scaleX:0.5693,scaleY:0.5693,rotation:114,x:702.7675,y:283.2263},0).wait(1).to({scaleX:0.5799,scaleY:0.5799,rotation:112,x:698.7955,y:280.216},0).wait(1).to({scaleX:0.5904,scaleY:0.5904,rotation:110,x:694.7786,y:277.0935},0).wait(1).to({scaleX:0.601,scaleY:0.601,rotation:108,x:690.7141,y:273.8218},0).wait(1).to({scaleX:0.6115,scaleY:0.6115,rotation:106,x:686.5497,y:270.514},0).wait(1).to({scaleX:0.6221,scaleY:0.6221,rotation:104,x:682.3836,y:267.0335},0).wait(1).to({scaleX:0.6326,scaleY:0.6326,rotation:102,x:678.1147,y:263.4436},0).wait(1).to({scaleX:0.6432,scaleY:0.6432,rotation:100,x:673.7923,y:259.8079},0).wait(1).to({scaleX:0.6537,scaleY:0.6537,rotation:98,x:669.4165,y:255.9901},0).wait(1).to({scaleX:0.6643,scaleY:0.6643,rotation:96,x:664.9378,y:252.1538},0).wait(1).to({scaleX:0.6748,scaleY:0.6748,rotation:94,x:660.3575,y:248.1627},0).wait(1).to({scaleX:0.6854,scaleY:0.6854,rotation:92,x:655.7272,y:244.0807},0).wait(1).to({scaleX:0.6959,scaleY:0.6959,rotation:90,x:650.9493,y:239.9214},0).wait(1).to({scaleX:0.7065,scaleY:0.7065,rotation:88,x:646.0767,y:235.6985},0).wait(1).to({scaleX:0.717,scaleY:0.717,rotation:86,x:641.163,y:231.3758},0).wait(1).to({scaleX:0.7276,scaleY:0.7276,rotation:84,x:636.0623,y:226.9666},0).wait(1).to({scaleX:0.7381,scaleY:0.7381,rotation:82,x:630.8794,y:222.4346},0).wait(1).to({scaleX:0.7486,scaleY:0.7486,rotation:80,x:625.6195,y:217.893},0).wait(1).to({scaleX:0.7592,scaleY:0.7592,rotation:78,x:620.1886,y:213.2549},0).wait(1).to({scaleX:0.7697,scaleY:0.7697,rotation:76,x:614.6432,y:208.5834},0).wait(1).to({scaleX:0.7803,scaleY:0.7803,rotation:74,x:608.9902,y:203.8412},0).wait(1).to({scaleX:0.7908,scaleY:0.7908,rotation:72,x:603.1874,y:199.0407},0).wait(1).to({scaleX:0.8014,scaleY:0.8014,rotation:70,x:597.2429,y:194.1944},0).wait(1).to({scaleX:0.8119,scaleY:0.8119,rotation:68,x:591.1655,y:189.2641},0).wait(1).to({scaleX:0.8225,scaleY:0.8225,rotation:66,x:584.9644,y:184.3615},0).wait(1).to({scaleX:0.833,scaleY:0.833,rotation:64,x:578.5995,y:179.398},0).wait(1).to({scaleX:0.8436,scaleY:0.8436,rotation:62,x:572.0811,y:174.3847},0).wait(1).to({scaleX:0.8541,scaleY:0.8541,rotation:60,x:565.4201,y:169.382},0).wait(1).to({scaleX:0.8647,scaleY:0.8647,rotation:58,x:558.6278,y:164.3503},0).wait(1).to({scaleX:0.8752,scaleY:0.8752,rotation:56,x:551.6659,y:159.2994},0).wait(1).to({scaleX:0.8858,scaleY:0.8858,rotation:54,x:544.5469,y:154.2886},0).wait(1).to({scaleX:0.8963,scaleY:0.8963,rotation:52,x:537.2834,y:149.2269},0).wait(1).to({scaleX:0.9069,scaleY:0.9069,rotation:50,x:529.8886,y:144.2227},0).wait(1).to({scaleX:0.9174,scaleY:0.9174,rotation:48,x:522.276,y:139.2339},0).wait(1).to({scaleX:0.928,scaleY:0.928,rotation:46,x:514.5596,y:134.218},0).wait(1).to({scaleX:0.9385,scaleY:0.9385,rotation:44,x:506.6538,y:129.2818},0).wait(1).to({scaleX:0.9491,scaleY:0.9491,rotation:42,x:498.6232,y:124.3318},0).wait(1).to({scaleX:0.9596,scaleY:0.9596,rotation:40,x:490.4329,y:119.4736},0).wait(1).to({scaleX:0.9702,scaleY:0.9702,rotation:38,x:482.0482,y:114.6625},0).wait(1).to({scaleX:0.9807,scaleY:0.9807,rotation:36,x:473.5346,y:109.853},0).wait(1).to({scaleX:0.9912,scaleY:0.9912,rotation:34,x:464.8582,y:105.1492},0).wait(1).to({scaleX:1.0018,scaleY:1.0018,rotation:32,x:456.035,y:100.5043},0).wait(1).to({scaleX:1.0123,scaleY:1.0123,rotation:30,x:447.0813,y:95.9713},0).wait(1).to({scaleX:1.0229,scaleY:1.0229,rotation:28,x:437.9637,y:91.452},0).wait(1).to({scaleX:1.0335,scaleY:1.0335,rotation:26,x:428.6989,y:87.0979},0).wait(1).to({scaleX:1.044,scaleY:1.044,rotation:24,x:419.2537,y:82.7599},0).wait(1).to({scaleX:1.0545,scaleY:1.0545,rotation:22,x:409.6951,y:78.5879},0).wait(1).to({scaleX:1.0651,scaleY:1.0651,rotation:20,x:400.0401,y:74.4814},0).wait(1).to({scaleX:1.0756,scaleY:1.0756,rotation:18,x:390.2059,y:70.4891},0).wait(1).to({scaleX:1.0862,scaleY:1.0862,rotation:16,x:380.2095,y:66.6591},0).wait(1).to({scaleX:1.0967,scaleY:1.0967,rotation:14,x:370.1181,y:62.9386},0).wait(1).to({scaleX:1.1073,scaleY:1.1073,rotation:12,x:359.9488,y:59.3243},0).wait(1).to({scaleX:1.1179,scaleY:1.1179,rotation:10,x:349.5687,y:55.8622},0).wait(1).to({scaleX:1.1284,scaleY:1.1284,rotation:8,x:339.1448,y:52.5475},0).wait(1).to({scaleX:1.139,scaleY:1.139,rotation:6,x:328.594,y:49.3747},0).wait(1).to({scaleX:1.1495,scaleY:1.1495,rotation:4,x:317.933,y:46.3377},0).wait(1).to({scaleX:1.1601,scaleY:1.1601,rotation:2,x:307.1784,y:43.4796},0).wait(1).to({scaleX:1.1706,scaleY:1.1706,rotation:0,x:296.2967,y:40.7929},0).wait(121));

	// Calque_5
	this.text_6 = new cjs.Text("Le canard jaune avance", "italic 30px 'Harlow Solid Italic'");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 40;
	this.text_6.lineWidth = 593;
	this.text_6.parent = this;
	this.text_6.setTransform(301.5,-39.95);
	this.text_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_6).wait(30).to({_off:false},0).wait(1320).to({y:-37.7833},0).wait(1).to({y:-35.6167},0).wait(1).to({y:-33.45},0).wait(1).to({y:-31.2833},0).wait(1).to({y:-29.1167},0).wait(1).to({y:-26.95},0).wait(1).to({y:-24.7833},0).wait(1).to({y:-22.6167},0).wait(1).to({y:-20.45},0).wait(1).to({y:-18.2833},0).wait(1).to({y:-16.1167},0).wait(1).to({y:-13.95},0).wait(1).to({y:-11.7833},0).wait(1).to({y:-9.6167},0).wait(1).to({y:-7.45},0).wait(1).to({y:-5.2833},0).wait(1).to({y:-3.1167},0).wait(1).to({y:-0.95},0).wait(1).to({y:1.2167},0).wait(1).to({y:3.3833},0).wait(1).to({y:5.55},0).wait(1).to({y:7.7167},0).wait(1).to({y:9.8833},0).wait(1).to({y:12.05},0).wait(1).to({y:14.2167},0).wait(1).to({y:16.3833},0).wait(1).to({y:18.55},0).wait(1).to({y:20.7167},0).wait(1).to({y:22.8833},0).wait(1).to({y:25.05},0).wait(61).to({x:316.4983,y:25.0817},0).wait(1).to({x:331.4967,y:25.1133},0).wait(1).to({x:346.495,y:25.145},0).wait(1).to({x:361.4933,y:25.1767},0).wait(1).to({x:376.4917,y:25.2083},0).wait(1).to({x:391.49,y:25.24},0).wait(1).to({x:406.4883,y:25.2717},0).wait(1).to({x:421.4867,y:25.3033},0).wait(1).to({x:436.485,y:25.335},0).wait(1).to({x:451.4833,y:25.3667},0).wait(1).to({x:466.4817,y:25.3983},0).wait(1).to({x:481.48,y:25.43},0).wait(1).to({x:496.4783,y:25.4617},0).wait(1).to({x:511.4767,y:25.4933},0).wait(1).to({x:526.475,y:25.525},0).wait(1).to({x:541.4733,y:25.5567},0).wait(1).to({x:556.4717,y:25.5883},0).wait(1).to({x:571.47,y:25.62},0).wait(1).to({x:586.4683,y:25.6517},0).wait(1).to({x:601.4667,y:25.6833},0).wait(1).to({x:616.465,y:25.715},0).wait(1).to({x:631.4633,y:25.7467},0).wait(1).to({x:646.4617,y:25.7783},0).wait(1).to({x:661.46,y:25.81},0).wait(1).to({x:676.4583,y:25.8417},0).wait(1).to({x:691.4567,y:25.8733},0).wait(1).to({x:706.455,y:25.905},0).wait(1).to({x:721.4533,y:25.9367},0).wait(1).to({x:736.4517,y:25.9683},0).wait(1).to({x:751.45,y:26},0).wait(61).to({_off:true},1).wait(149));

	// Calque_6
	this.text_7 = new cjs.Text("Le canard jaune dépasse le canard rouge", "italic 30px 'Harlow Solid Italic'");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 40;
	this.text_7.lineWidth = 597;
	this.text_7.parent = this;
	this.text_7.setTransform(299.5,-39.95);

	this.timeline.addTween(cjs.Tween.get(this.text_7).wait(1110).to({y:-37.85},0).wait(1).to({y:-35.75},0).wait(1).to({y:-33.65},0).wait(1).to({y:-31.55},0).wait(1).to({y:-29.45},0).wait(1).to({y:-27.35},0).wait(1).to({y:-25.25},0).wait(1).to({y:-23.15},0).wait(1).to({y:-21.05},0).wait(1).to({y:-18.95},0).wait(1).to({y:-16.85},0).wait(1).to({y:-14.75},0).wait(1).to({y:-12.65},0).wait(1).to({y:-10.55},0).wait(1).to({y:-8.45},0).wait(1).to({y:-6.35},0).wait(1).to({y:-4.25},0).wait(1).to({y:-2.15},0).wait(1).to({y:-0.05},0).wait(1).to({y:2.05},0).wait(1).to({y:4.15},0).wait(1).to({y:6.25},0).wait(1).to({y:8.35},0).wait(1).to({y:10.45},0).wait(1).to({y:12.55},0).wait(1).to({y:14.65},0).wait(1).to({y:16.75},0).wait(1).to({y:18.85},0).wait(1).to({y:20.95},0).wait(1).to({y:23.05},0).wait(61).to({x:317.9667,y:23.1483},0).wait(1).to({x:336.4333,y:23.2467},0).wait(1).to({x:354.9,y:23.345},0).wait(1).to({x:373.3667,y:23.4433},0).wait(1).to({x:391.8333,y:23.5417},0).wait(1).to({x:410.3,y:23.64},0).wait(1).to({x:428.7667,y:23.7383},0).wait(1).to({x:447.2333,y:23.8367},0).wait(1).to({x:465.7,y:23.935},0).wait(1).to({x:484.1667,y:24.0333},0).wait(1).to({x:502.6333,y:24.1317},0).wait(1).to({x:521.1,y:24.23},0).wait(1).to({x:539.5667,y:24.3283},0).wait(1).to({x:558.0333,y:24.4267},0).wait(1).to({x:576.5,y:24.525},0).wait(1).to({x:594.9667,y:24.6233},0).wait(1).to({x:613.4333,y:24.7217},0).wait(1).to({x:631.9,y:24.82},0).wait(1).to({x:650.3667,y:24.9183},0).wait(1).to({x:668.8333,y:25.0167},0).wait(1).to({x:687.3,y:25.115},0).wait(1).to({x:705.7667,y:25.2133},0).wait(1).to({x:724.2333,y:25.3117},0).wait(1).to({x:742.7,y:25.41},0).wait(1).to({x:761.1667,y:25.5083},0).wait(1).to({x:779.6333,y:25.6067},0).wait(1).to({x:798.1,y:25.705},0).wait(1).to({x:816.5667,y:25.8033},0).wait(1).to({x:835.0333,y:25.9017},0).wait(1).to({x:853.5,y:26},0).wait(271).to({_off:true},1).wait(179));

	// Calque_4
	this.text_8 = new cjs.Text("Un étudiant tire sur la cible\n", "italic 30px 'Harlow Solid Italic'");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 40;
	this.text_8.lineWidth = 593;
	this.text_8.parent = this;
	this.text_8.setTransform(312,-76.85);

	this.timeline.addTween(cjs.Tween.get(this.text_8).wait(1200).to({y:-73.9783},0).wait(1).to({y:-71.1067},0).wait(1).to({y:-68.235},0).wait(1).to({y:-65.3633},0).wait(1).to({y:-62.4917},0).wait(1).to({y:-59.62},0).wait(1).to({y:-56.7483},0).wait(1).to({y:-53.8767},0).wait(1).to({y:-51.005},0).wait(1).to({y:-48.1333},0).wait(1).to({y:-45.2617},0).wait(1).to({y:-42.39},0).wait(1).to({y:-39.5183},0).wait(1).to({y:-36.6467},0).wait(1).to({y:-33.775},0).wait(1).to({y:-30.9033},0).wait(1).to({y:-28.0317},0).wait(1).to({y:-25.16},0).wait(1).to({y:-22.2883},0).wait(1).to({y:-19.4167},0).wait(1).to({y:-16.545},0).wait(1).to({y:-13.6733},0).wait(1).to({y:-10.8017},0).wait(1).to({y:-7.93},0).wait(1).to({y:-5.0583},0).wait(1).to({y:-2.1867},0).wait(1).to({y:0.685},0).wait(1).to({y:3.5567},0).wait(1).to({y:6.4283},0).wait(1).to({y:9.3},0).wait(61).to({x:328.7},0).wait(1).to({x:345.4},0).wait(1).to({x:362.1},0).wait(1).to({x:378.8},0).wait(1).to({x:395.5},0).wait(1).to({x:412.2},0).wait(1).to({x:428.9},0).wait(1).to({x:445.6},0).wait(1).to({x:462.3},0).wait(1).to({x:479},0).wait(1).to({x:495.7},0).wait(1).to({x:512.4},0).wait(1).to({x:529.1},0).wait(1).to({x:545.8},0).wait(1).to({x:562.5},0).wait(1).to({x:579.2},0).wait(1).to({x:595.9},0).wait(1).to({x:612.6},0).wait(1).to({x:629.3},0).wait(1).to({x:646},0).wait(1).to({x:662.7},0).wait(1).to({x:679.4},0).wait(1).to({x:696.1},0).wait(1).to({x:712.8},0).wait(1).to({x:729.5},0).wait(1).to({x:746.2},0).wait(1).to({x:762.9},0).wait(1).to({x:779.6},0).wait(1).to({x:796.3},0).wait(1).to({x:813},0).to({_off:true},1).wait(360));

	// Calque_3
	this.text_9 = new cjs.Text("Le canard jaune dépasse\nle canard rouge", "italic 30px 'Harlow Solid Italic'");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 40;
	this.text_9.lineWidth = 562;
	this.text_9.parent = this;
	this.text_9.setTransform(301,-79.2);

	this.timeline.addTween(cjs.Tween.get(this.text_9).wait(1199).to({_off:true},1).wait(480));

	// Calque_2
	this.instance_181 = new lib.Symbole7();
	this.instance_181.setTransform(381.6,-52.9,1,1,0,0,0,54.6,86.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_181).wait(1).to({x:381.55},0).wait(1).to({x:381.5},0).wait(2).to({x:381.45},0).wait(2).to({x:381.4},0).wait(2).to({x:381.35},0).wait(2).to({x:381.3},0).wait(2).to({x:381.25},0).wait(2).to({x:381.2},0).wait(1).to({x:381.15},0).wait(2).to({x:381.1},0).wait(2).to({x:381.05},0).wait(2).to({x:381},0).wait(2).to({x:380.95},0).wait(2).to({x:380.9},0).wait(2).to({x:380.85},0).wait(2).to({x:380.8},0).wait(1).to({x:380.75},0).wait(2).to({x:380.7},0).wait(2).to({x:380.65},0).wait(2).to({x:380.6},0).wait(2).to({x:380.55},0).wait(2).to({x:380.5},0).wait(2).to({x:380.45},0).wait(2).to({x:380.4},0).wait(1).to({x:380.35},0).wait(2).to({x:380.3},0).wait(2).to({x:380.25},0).wait(2).to({x:380.2},0).wait(2).to({x:380.15},0).wait(2).to({x:380.1},0).wait(2).to({x:380.05},0).wait(1).to({x:380},0).wait(2).to({x:379.95},0).wait(2).to({x:379.9},0).wait(2).to({x:379.85},0).wait(2).to({x:379.8},0).wait(2).to({x:379.75},0).wait(2).to({x:379.7},0).wait(2).to({x:379.65},0).wait(1).to({x:379.6},0).wait(2).to({x:379.55},0).wait(2).to({x:379.5},0).wait(2).to({x:379.45},0).wait(2).to({x:379.4},0).wait(2).to({x:379.35},0).wait(2).to({x:379.3},0).wait(2).to({x:379.25},0).wait(1).to({x:379.2},0).wait(2).to({x:379.15},0).wait(2).to({x:379.1},0).wait(2).to({x:379.05},0).wait(2).to({x:379},0).wait(2).to({x:378.95},0).wait(2).to({x:378.9},0).wait(1).to({x:378.85},0).wait(2).to({x:378.8},0).wait(2).to({x:378.75},0).wait(2).to({x:378.7},0).wait(2).to({x:378.65},0).wait(2).to({x:378.6},0).wait(2).to({x:378.55},0).wait(2).to({x:378.5},0).wait(1).to({x:378.45},0).wait(2).to({x:378.4},0).wait(2).to({x:378.35},0).wait(2).to({x:378.3},0).wait(2).to({x:378.25},0).wait(2).to({x:378.2},0).wait(2).to({x:378.15},0).wait(2).to({x:378.1},0).wait(1).to({x:378.05},0).wait(2).to({x:378},0).wait(2).to({x:377.95},0).wait(2).to({x:377.9},0).wait(2).to({x:377.85},0).wait(2).to({x:377.8},0).wait(2).to({x:377.75},0).wait(1).to({x:377.7},0).wait(2).to({x:377.65},0).wait(2).to({x:377.6},0).wait(2).to({x:377.55},0).wait(2).to({x:377.5},0).wait(2).to({x:377.45},0).wait(2).to({x:377.4},0).wait(2).to({x:377.35},0).wait(1).to({x:377.3},0).wait(2).to({x:377.25},0).wait(2).to({x:377.2},0).wait(2).to({x:377.15},0).wait(2).to({x:377.1},0).wait(2).to({x:377.05},0).wait(2).to({x:377},0).wait(2).to({x:376.95},0).wait(1).to({x:376.9},0).wait(2).to({x:376.85},0).wait(2).to({x:376.8},0).wait(2).to({x:376.75},0).wait(2).to({x:376.7},0).wait(2).to({x:376.65},0).wait(2).to({x:376.6},0).wait(1).to({x:376.55},0).wait(2).to({x:376.5},0).wait(2).to({x:376.45},0).wait(2).to({x:376.4},0).wait(2).to({x:376.35},0).wait(2).to({x:376.3},0).wait(2).to({x:376.25},0).wait(2).to({x:376.2},0).wait(1).to({x:376.15},0).wait(2).to({x:376.1},0).wait(2).to({x:376.05},0).wait(2).to({x:376},0).wait(2).to({x:375.95},0).wait(2).to({x:375.9},0).wait(2).to({x:375.85},0).wait(2).to({x:375.8},0).wait(1).to({x:375.75},0).wait(2).to({x:375.7},0).wait(2).to({x:375.65},0).wait(2).to({x:375.6},0).wait(2).to({x:375.55},0).wait(2).to({x:375.5},0).wait(2).to({x:375.45},0).wait(1).to({x:375.4},0).wait(2).to({x:375.35},0).wait(2).to({x:375.3},0).wait(2).to({x:375.25},0).wait(2).to({x:375.2},0).wait(2).to({x:375.15},0).wait(2).to({x:375.1},0).wait(2).to({x:375.05},0).wait(1).to({x:375},0).wait(2).to({x:374.95},0).wait(2).to({x:374.9},0).wait(2).to({x:374.85},0).wait(2).to({x:374.8},0).wait(2).to({x:374.75},0).wait(2).to({x:374.7},0).wait(2).to({x:374.65},0).wait(1).to({x:374.6},0).wait(2).to({x:374.55},0).wait(2).to({x:374.5},0).wait(2).to({x:374.45},0).wait(2).to({x:374.4},0).wait(2).to({x:374.35},0).wait(2).to({x:374.3},0).wait(2).to({x:374.25},0).wait(1).to({x:374.2},0).wait(2).to({x:374.15},0).wait(2).to({x:374.1},0).wait(2).to({x:374.05},0).wait(2).to({x:374},0).wait(2).to({x:373.95},0).wait(2).to({x:373.9},0).wait(1).to({x:373.85},0).wait(2).to({x:373.8},0).wait(2).to({x:373.75},0).wait(2).to({x:373.7},0).wait(2).to({x:373.65},0).wait(2).to({x:373.6},0).wait(2).to({x:373.55},0).wait(2).to({x:373.5},0).wait(1).to({x:373.45},0).wait(2).to({x:373.4},0).wait(2).to({x:373.35},0).wait(2).to({x:373.3},0).wait(2).to({x:373.25},0).wait(2).to({x:373.2},0).wait(2).to({x:373.15},0).wait(2).to({x:373.1},0).wait(1).to({x:373.05},0).wait(2).to({x:373},0).wait(2).to({x:372.95},0).wait(2).to({x:372.9},0).wait(2).to({x:372.85},0).wait(2).to({x:372.8},0).wait(2).to({x:372.75},0).wait(1).to({x:372.7},0).wait(2).to({x:372.65},0).wait(2).to({x:372.6},0).wait(2).to({x:372.55},0).wait(2).to({x:372.5},0).wait(2).to({x:372.45},0).wait(2).to({x:372.4},0).wait(2).to({x:372.35},0).wait(1).to({x:372.3},0).wait(2).to({x:372.25},0).wait(2).to({x:372.2},0).wait(2).to({x:372.15},0).wait(2).to({x:372.1},0).wait(2).to({x:372.05},0).wait(2).to({x:372},0).wait(2).to({x:371.95},0).wait(1).to({x:371.9},0).wait(2).to({x:371.85},0).wait(2).to({x:371.8},0).wait(2).to({x:371.75},0).wait(2).to({x:371.7},0).wait(2).to({x:371.65},0).wait(2).to({x:371.6},0).wait(1).to({x:371.55},0).wait(2).to({x:371.5},0).wait(2).to({x:371.45},0).wait(2).to({x:371.4},0).wait(2).to({x:371.35},0).wait(2).to({x:371.3},0).wait(2).to({x:371.25},0).wait(2).to({x:371.2},0).wait(1).to({x:371.15},0).wait(2).to({x:371.1},0).wait(2).to({x:371.05},0).wait(2).to({x:371},0).wait(2).to({x:370.95},0).wait(2).to({x:370.9},0).wait(2).to({x:370.85},0).wait(2).to({x:370.8},0).wait(1).to({x:370.75},0).wait(2).to({x:370.7},0).wait(2).to({x:370.65},0).wait(2).to({x:370.6},0).wait(2).to({x:370.55},0).wait(2).to({x:370.5},0).wait(2).to({x:370.45},0).wait(1).to({x:370.4},0).wait(2).to({x:370.35},0).wait(2).to({x:370.3},0).wait(2).to({x:370.25},0).wait(2).to({x:370.2},0).wait(2).to({x:370.15},0).wait(2).to({x:370.1},0).wait(2).to({x:370.05},0).wait(1).to({x:370},0).wait(2).to({x:369.95},0).wait(2).to({x:369.9},0).wait(2).to({x:369.85},0).wait(2).to({x:369.8},0).wait(2).to({x:369.75},0).wait(2).to({x:369.7},0).wait(2).to({x:369.65},0).wait(1).to({x:369.6},0).wait(2).to({x:369.55},0).wait(2).to({x:369.5},0).wait(2).to({x:369.45},0).wait(2).to({x:369.4},0).wait(2).to({x:369.35},0).wait(2).to({x:369.3},0).wait(1).to({x:369.25},0).wait(2).to({x:369.2},0).wait(2).to({x:369.15},0).wait(2).to({x:369.1},0).wait(2).to({x:369.05},0).wait(2).to({x:369},0).wait(2).to({x:368.95},0).wait(2).to({x:368.9},0).wait(1).to({x:368.85},0).wait(2).to({x:368.8},0).wait(2).to({x:368.75},0).wait(2).to({x:368.7},0).wait(2).to({x:368.65},0).wait(2).to({x:368.6},0).wait(2).to({x:368.55},0).wait(2).to({x:368.5},0).wait(1).to({x:368.45},0).wait(2).to({x:368.4},0).wait(2).to({x:368.35},0).wait(2).to({x:368.3},0).wait(2).to({x:368.25},0).wait(2).to({x:368.2},0).wait(2).to({x:368.15},0).wait(1).to({x:368.1},0).wait(2).to({x:368.05},0).wait(2).to({x:368},0).wait(2).to({x:367.95},0).wait(2).to({x:367.9},0).wait(2).to({x:367.85},0).wait(2).to({x:367.8},0).wait(2).to({x:367.75},0).wait(1).to({x:367.7},0).wait(2).to({x:367.65},0).wait(2).to({x:367.6},0).wait(2).to({x:367.55},0).wait(2).to({x:367.5},0).wait(2).to({x:367.45},0).wait(2).to({x:367.4},0).wait(2).to({x:367.35},0).wait(1).to({x:367.3},0).wait(2).to({x:367.25},0).wait(2).to({x:367.2},0).wait(2).to({x:367.15},0).wait(2).to({x:367.1},0).wait(2).to({x:367.05},0).wait(2).to({x:367},0).wait(2).to({x:366.95},0).wait(1).to({x:366.9},0).wait(2).to({x:366.85},0).wait(2).to({x:366.8},0).wait(2).to({x:366.75},0).wait(2).to({x:366.7},0).wait(2).to({x:366.65},0).wait(2).to({x:366.6},0).wait(1).to({x:366.55},0).wait(2).to({x:366.5},0).wait(2).to({x:366.45},0).wait(2).to({x:366.4},0).wait(2).to({x:366.35},0).wait(2).to({x:366.3},0).wait(2).to({x:366.25},0).wait(2).to({x:366.2},0).wait(1).to({x:366.15},0).wait(2).to({x:366.1},0).wait(2).to({x:366.05},0).wait(2).to({x:366},0).wait(2).to({x:365.95},0).wait(2).to({x:365.9},0).wait(2).to({x:365.85},0).wait(2).to({x:365.8},0).wait(1).to({x:365.75},0).wait(2).to({x:365.7},0).wait(2).to({x:365.65},0).wait(2).to({x:365.6},0).wait(2).to({x:365.55},0).wait(2).to({x:365.5},0).wait(2).to({x:365.45},0).wait(1).to({x:365.4},0).wait(2).to({x:365.35},0).wait(2).to({x:365.3},0).wait(2).to({x:365.25},0).wait(2).to({x:365.2},0).wait(2).to({x:365.15},0).wait(2).to({x:365.1},0).wait(2).to({x:365.05},0).wait(1).to({x:365},0).wait(2).to({x:364.95},0).wait(2).to({x:364.9},0).wait(2).to({x:364.85},0).wait(2).to({x:364.8},0).wait(2).to({x:364.75},0).wait(2).to({x:364.7},0).wait(2).to({x:364.65},0).wait(1).to({x:364.6},0).wait(2).to({x:364.55},0).wait(2).to({x:364.5},0).wait(2).to({x:364.45},0).wait(2).to({x:364.4},0).wait(2).to({x:364.35},0).wait(2).to({x:364.3},0).wait(1).to({x:364.25},0).wait(2).to({x:364.2},0).wait(2).to({x:364.15},0).wait(2).to({x:364.1},0).wait(2).to({x:364.05},0).wait(2).to({x:364},0).wait(2).to({x:363.95},0).wait(2).to({x:363.9},0).wait(1).to({x:363.85},0).wait(2).to({x:363.8},0).wait(2).to({x:363.75},0).wait(2).to({x:363.7},0).wait(2).to({x:363.65},0).wait(2).to({x:363.6},0).wait(2).to({x:363.55},0).wait(2).to({x:363.5},0).wait(1).to({x:363.45},0).wait(2).to({x:363.4},0).wait(2).to({x:363.35},0).wait(2).to({x:363.3},0).wait(2).to({x:363.25},0).wait(2).to({x:363.2},0).wait(2).to({x:363.15},0).wait(1).to({x:363.1},0).wait(2).to({x:363.05},0).wait(2).to({x:363},0).wait(2).to({x:362.95},0).wait(2).to({x:362.9},0).wait(2).to({x:362.85},0).wait(2).to({x:362.8},0).wait(2).to({x:362.75},0).wait(1).to({x:362.7},0).wait(2).to({x:362.65},0).wait(2).to({x:362.6},0).wait(2).to({x:362.55},0).wait(2).to({x:362.5},0).wait(2).to({x:362.45},0).wait(2).to({x:362.4},0).wait(2).to({x:362.35},0).wait(1).to({x:362.3},0).wait(2).to({x:362.25},0).wait(2).to({x:362.2},0).wait(2).to({x:362.15},0).wait(2).to({x:362.1},0).wait(2).to({x:362.05},0).wait(2).to({x:362},0).wait(1).to({x:361.95},0).wait(2).to({x:361.9},0).wait(2).to({x:361.85},0).wait(2).to({x:361.8},0).wait(2).to({x:361.75},0).wait(2).to({x:361.7},0).wait(2).to({x:361.65},0).wait(2).to({x:361.6},0).wait(1).to({x:361.55},0).wait(2).to({x:361.5},0).wait(2).to({x:361.45},0).wait(2).to({x:361.4},0).wait(2).to({x:361.35},0).wait(2).to({x:361.3},0).wait(2).to({x:361.25},0).wait(2).to({x:361.2},0).wait(1).to({x:361.15},0).wait(2).to({x:361.1},0).wait(2).to({x:361.05},0).wait(2).to({x:361},0).wait(2).to({x:360.95},0).wait(2).to({x:360.9},0).wait(2).to({x:360.85},0).wait(1).to({x:360.8},0).wait(2).to({x:360.75},0).wait(2).to({x:360.7},0).wait(2).to({x:360.65},0).wait(2).to({x:360.6},0).wait(2).to({x:360.55},0).wait(2).to({x:360.5},0).wait(2).to({x:360.45},0).wait(1).to({x:360.4},0).wait(2).to({x:360.35},0).wait(2).to({x:360.3},0).wait(2).to({x:360.25},0).wait(2).to({x:360.2},0).wait(2).to({x:360.15},0).wait(2).to({x:360.1},0).wait(2).to({x:360.05},0).wait(1).to({x:360},0).wait(2).to({x:359.95},0).wait(2).to({x:359.9},0).wait(2).to({x:359.85},0).wait(2).to({x:359.8},0).wait(2).to({x:359.75},0).wait(2).to({x:359.7},0).wait(2).to({x:359.65},0).wait(1).to({x:359.6},0).wait(2).to({x:359.55},0).wait(2).to({x:359.5},0).wait(2).to({x:359.45},0).wait(2).to({x:359.4},0).wait(2).to({x:359.35},0).wait(2).to({x:359.3},0).wait(1).to({x:359.25},0).wait(2).to({x:359.2},0).wait(2).to({x:359.15},0).wait(2).to({x:359.1},0).wait(2).to({x:359.05},0).wait(2).to({x:359},0).wait(2).to({x:358.95},0).wait(2).to({x:358.9},0).wait(1).to({x:358.85},0).wait(2).to({x:358.8},0).wait(2).to({x:358.75},0).wait(2).to({x:358.7},0).wait(2).to({x:358.65},0).wait(2).to({x:358.6},0).wait(2).to({x:358.55},0).wait(2).to({x:358.5},0).wait(1).to({x:358.45},0).wait(2).to({x:358.4},0).wait(2).to({x:358.35},0).wait(2).to({x:358.3},0).wait(2).to({x:358.25},0).wait(2).to({x:358.2},0).wait(2).to({x:358.15},0).wait(1).to({x:358.1},0).wait(2).to({x:358.05},0).wait(2).to({x:358},0).wait(2).to({x:357.95},0).wait(2).to({x:357.9},0).wait(2).to({x:357.85},0).wait(2).to({x:357.8},0).wait(2).to({x:357.75},0).wait(1).to({x:357.7},0).wait(2).to({x:357.65},0).wait(2).to({x:357.6},0).wait(2).to({x:357.55},0).wait(2).to({x:357.5},0).wait(2).to({x:357.45},0).wait(2).to({x:357.4},0).wait(2).to({x:357.35},0).wait(1).to({x:357.3},0).wait(2).to({x:357.25},0).wait(2).to({x:357.2},0).wait(2).to({x:357.15},0).wait(2).to({x:357.1},0).wait(2).to({x:357.05},0).wait(2).to({x:357},0).wait(1).to({x:356.95},0).wait(2).to({x:356.9},0).wait(2).to({x:356.85},0).wait(2).to({x:356.8},0).wait(2).to({x:356.75},0).wait(2).to({x:356.7},0).wait(2).to({x:356.65},0).wait(2).to({x:356.6},0).wait(1).to({x:356.55},0).wait(2).to({x:356.5},0).wait(2).to({x:356.45},0).wait(2).to({x:356.4},0).wait(2).to({x:356.35},0).wait(2).to({x:356.3},0).wait(2).to({x:356.25},0).wait(2).to({x:356.2},0).wait(1).to({x:356.15},0).wait(2).to({x:356.1},0).wait(2).to({x:356.05},0).wait(2).to({x:356},0).wait(2).to({x:355.95},0).wait(2).to({x:355.9},0).wait(2).to({x:355.85},0).wait(1).to({x:355.8},0).wait(2).to({x:355.75},0).wait(2).to({x:355.7},0).wait(2).to({x:355.65},0).wait(2).to({x:355.6},0).wait(2).to({x:355.55},0).wait(2).to({x:355.5},0).wait(2).to({x:355.45},0).wait(1).to({x:355.4},0).wait(2).to({x:355.35},0).wait(2).to({x:355.3},0).wait(2).to({x:355.25},0).wait(2).to({x:355.2},0).wait(2).to({x:355.15},0).wait(2).to({x:355.1},0).wait(2).to({x:355.05},0).wait(1).to({x:355},0).wait(2).to({x:354.95},0).wait(2).to({x:354.9},0).wait(2).to({x:354.85},0).wait(2).to({x:354.8},0).wait(2).to({x:354.75},0).wait(2).to({x:354.7},0).wait(1).to({x:354.65},0).wait(2).to({x:354.6},0).wait(2).to({x:354.55},0).wait(2).to({x:354.5},0).wait(2).to({x:354.45},0).wait(2).to({x:354.4},0).wait(2).to({x:354.35},0).wait(2).to({x:354.3},0).wait(1).to({x:354.25},0).wait(2).to({x:354.2},0).wait(2).to({x:354.15},0).wait(2).to({x:354.1},0).wait(2).to({x:354.05},0).wait(2).to({x:354},0).wait(2).to({x:353.95},0).wait(2).to({x:353.9},0).wait(1).to({x:353.85},0).wait(2).to({x:353.8},0).wait(2).to({x:353.75},0).wait(2).to({x:353.7},0).wait(2).to({x:353.65},0).wait(2).to({x:353.6},0).wait(2).to({x:353.55},0).wait(2).to({y:-47.45},0).wait(1).to({y:-42},0).wait(1).to({x:353.6,y:-36.6},0).wait(1).to({y:-31.15},0).wait(1).to({y:-25.7},0).wait(1).to({x:353.65,y:-20.3},0).wait(1).to({y:-14.85},0).wait(1).to({y:-9.4},0).wait(1).to({x:353.7,y:-4},0).wait(1).to({y:1.45},0).wait(1).to({y:6.9},0).wait(1).to({x:353.75,y:12.3},0).wait(1).to({y:17.75},0).wait(1).to({y:23.2},0).wait(1).to({x:353.8,y:28.6},0).wait(1).to({y:34.05},0).wait(1).to({y:39.5},0).wait(1).to({x:353.85,y:44.9},0).wait(1).to({y:50.35},0).wait(1).to({y:55.8},0).wait(1).to({x:353.9,y:61.2},0).wait(1).to({y:66.65},0).wait(1).to({y:72.1},0).wait(1).to({x:353.95,y:77.5},0).wait(1).to({y:82.95},0).wait(1).to({y:88.35},0).wait(1).to({x:354,y:93.8},0).wait(1).to({y:99.2},0).wait(1).to({y:104.65},0).wait(1).to({x:354.05,y:110.1},0).wait(210).to({_off:true},1).wait(390));

	// Calque_1
	this.text_10 = new cjs.Text("Un étudiant vise le canard jaune", "italic 30px 'Harlow Solid Italic'");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 40;
	this.text_10.lineWidth = 601;
	this.text_10.parent = this;
	this.text_10.setTransform(302.5,-40.2);

	this.timeline.addTween(cjs.Tween.get(this.text_10).to({_off:true},929).wait(59).to({_off:false,y:-39.2},0).wait(1).to({y:-37.3935},0).wait(1).to({y:-35.5871},0).wait(1).to({y:-33.7806},0).wait(1).to({y:-31.9742},0).wait(1).to({y:-30.1677},0).wait(1).to({y:-28.3613},0).wait(1).to({y:-26.5548},0).wait(1).to({y:-24.7484},0).wait(1).to({y:-22.9419},0).wait(1).to({y:-21.1355},0).wait(1).to({y:-19.329},0).wait(1).to({y:-17.5226},0).wait(1).to({y:-15.7161},0).wait(1).to({y:-13.9097},0).wait(1).to({y:-12.1032},0).wait(1).to({y:-10.2968},0).wait(1).to({y:-8.4903},0).wait(1).to({y:-6.6839},0).wait(1).to({y:-4.8774},0).wait(1).to({y:-3.071},0).wait(1).to({y:-1.2645},0).wait(1).to({y:0.5419},0).wait(1).to({y:2.3484},0).wait(1).to({y:4.1548},0).wait(1).to({y:5.9613},0).wait(1).to({y:7.7677},0).wait(1).to({y:9.5742},0).wait(1).to({y:11.3806},0).wait(1).to({y:13.1871},0).wait(1).to({y:14.9935},0).wait(1).to({y:16.8},0).wait(31).to({x:320.5667},0).wait(1).to({x:338.6333},0).wait(1).to({x:356.7},0).wait(1).to({x:374.7667},0).wait(1).to({x:392.8333},0).wait(1).to({x:410.9},0).wait(1).to({x:428.9667},0).wait(1).to({x:447.0333},0).wait(1).to({x:465.1},0).wait(1).to({x:483.1667},0).wait(1).to({x:501.2333},0).wait(1).to({x:519.3},0).wait(1).to({x:537.3667},0).wait(1).to({x:555.4333},0).wait(1).to({x:573.5},0).wait(1).to({x:591.5667},0).wait(1).to({x:609.6333},0).wait(1).to({x:627.7},0).wait(1).to({x:645.7667},0).wait(1).to({x:663.8333},0).wait(1).to({x:681.9},0).wait(1).to({x:699.9667},0).wait(1).to({x:718.0333},0).wait(1).to({x:736.1},0).wait(1).to({x:754.1667},0).wait(1).to({x:772.2333},0).wait(1).to({x:790.3},0).wait(1).to({x:808.3667},0).wait(1).to({x:826.4333},0).wait(1).to({x:844.5},0).to({_off:true},1).wait(600));

	// Calque_20
	this.instance_182 = new lib.Symbole4();
	this.instance_182.setTransform(52.5,238.5,1,1,0,0,0,69.5,109.5);
	this.instance_182._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_182).wait(539).to({_off:false},0).wait(1).to({x:67.35},0).wait(1).to({x:82.15},0).wait(1).to({x:96.95},0).wait(1).to({x:111.8},0).wait(1).to({x:126.65},0).wait(1).to({x:141.45},0).wait(1).to({x:156.3},0).wait(1).to({x:171.15},0).wait(1).to({x:185.95},0).wait(1).to({x:200.8},0).wait(1).to({x:215.6},0).wait(1).to({x:230.45},0).wait(1).to({x:245.3},0).wait(1).to({x:260.1},0).wait(1).to({x:274.95},0).wait(1).to({x:289.8},0).wait(1).to({x:304.6},0).wait(1).to({x:319.45},0).wait(1).to({x:334.3},0).wait(1).to({x:349.1},0).wait(1).to({x:363.95},0).wait(1).to({x:378.75},0).wait(1).to({x:393.6},0).wait(1).to({x:408.45},0).wait(1).to({x:423.25},0).wait(1).to({x:438.1},0).wait(1).to({x:452.95},0).wait(1).to({x:467.75},0).wait(1).to({x:482.6},0).wait(1).to({x:497.45},0).wait(211).to({x:502.65},0).wait(1).to({x:507.85},0).wait(1).to({x:513.05},0).wait(1).to({x:518.25},0).wait(1).to({x:523.45},0).wait(1).to({x:528.65},0).wait(1).to({x:533.85},0).wait(1).to({x:539.05},0).wait(1).to({x:544.25},0).wait(1).to({x:549.45},0).wait(1).to({x:554.65},0).wait(1).to({x:559.85},0).wait(1).to({x:565.05},0).wait(1).to({x:570.25},0).wait(1).to({x:575.45},0).wait(1).to({x:580.65},0).wait(1).to({x:585.85},0).wait(1).to({x:591.05},0).wait(1).to({x:596.25},0).wait(1).to({x:601.45},0).wait(1).to({x:606.65},0).wait(1).to({x:611.85},0).wait(1).to({x:617.05},0).wait(1).to({x:622.25},0).wait(1).to({x:627.45},0).wait(1).to({x:632.65},0).wait(1).to({x:637.85},0).wait(1).to({x:643.05},0).wait(1).to({x:648.25},0).wait(1).to({x:653.5},0).to({_off:true},1).wait(870));

	// Calque_19
	this.instance_183 = new lib.Symbole3();
	this.instance_183.setTransform(53,239,1,1,0,0,0,69,109);
	this.instance_183._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_183).wait(539).to({_off:false},0).wait(1).to({regX:69.2,x:62.95},0).wait(1).to({x:72.65},0).wait(1).to({x:82.4},0).wait(1).to({x:92.15},0).wait(1).to({x:101.85},0).wait(1).to({x:111.6},0).wait(1).to({x:121.35},0).wait(1).to({x:131.1},0).wait(1).to({x:140.8},0).wait(1).to({x:150.55},0).wait(1).to({x:160.3},0).wait(1).to({x:170.05},0).wait(1).to({x:179.75},0).wait(1).to({x:189.5},0).wait(1).to({x:199.25},0).wait(1).to({x:209},0).wait(1).to({x:218.75},0).wait(1).to({x:228.45},0).wait(1).to({x:238.2},0).wait(1).to({x:247.95},0).wait(1).to({x:257.7},0).wait(1).to({x:267.4},0).wait(1).to({x:277.15},0).wait(1).to({x:286.9},0).wait(1).to({x:296.65},0).wait(1).to({x:306.35},0).wait(1).to({x:316.1},0).wait(1).to({x:325.85},0).wait(1).to({x:335.6},0).wait(1).to({x:345.35,y:239.05},0).wait(211).to({x:350.65},0).wait(1).to({x:356},0).wait(1).to({x:361.35},0).wait(1).to({x:366.65},0).wait(1).to({x:372},0).wait(1).to({x:377.35},0).wait(1).to({x:382.7},0).wait(1).to({x:388},0).wait(1).to({x:393.35},0).wait(1).to({x:398.7},0).wait(1).to({x:404.05},0).wait(1).to({x:409.35},0).wait(1).to({x:414.7},0).wait(1).to({x:420.05},0).wait(1).to({x:425.4},0).wait(1).to({x:430.7},0).wait(1).to({x:436.05},0).wait(1).to({x:441.4},0).wait(1).to({x:446.7},0).wait(1).to({x:452.05},0).wait(1).to({x:457.4},0).wait(1).to({x:462.75},0).wait(1).to({x:468.05},0).wait(1).to({x:473.4},0).wait(1).to({x:478.75},0).wait(1).to({x:484.1},0).wait(1).to({x:489.4},0).wait(1).to({x:494.75},0).wait(1).to({x:500.1},0).wait(1).to({x:505.45},0).wait(331).to({x:500.2},0).wait(1).to({x:494.95},0).wait(1).to({x:489.75},0).wait(1).to({x:484.5},0).wait(1).to({x:479.25},0).wait(1).to({x:474.05},0).wait(1).to({x:468.8},0).wait(1).to({x:463.55},0).wait(1).to({x:458.35},0).wait(1).to({x:453.1},0).wait(1).to({x:447.85},0).wait(1).to({x:442.65},0).wait(1).to({x:437.4},0).wait(1).to({x:432.15},0).wait(1).to({x:426.95},0).wait(1).to({x:421.7},0).wait(1).to({x:416.45},0).wait(1).to({x:411.25},0).wait(1).to({x:406},0).wait(1).to({x:400.75},0).wait(1).to({x:395.55},0).wait(1).to({x:390.3},0).wait(1).to({x:385.05},0).wait(1).to({x:379.85},0).wait(1).to({x:374.6},0).wait(1).to({x:369.35},0).wait(1).to({x:364.15},0).wait(1).to({x:358.9},0).wait(1).to({x:353.65},0).wait(1).to({x:348.45},0).wait(91).to({scaleX:0.9798,scaleY:0.9798,rotation:6,y:243.7},0).wait(1).to({scaleX:0.9596,scaleY:0.9596,rotation:12,x:348.4,y:248.4},0).wait(1).to({scaleX:0.9393,scaleY:0.9393,rotation:18,x:348.35,y:253.1},0).wait(1).to({scaleX:0.9191,scaleY:0.9191,rotation:24,x:348.4,y:257.7},0).wait(1).to({scaleX:0.8989,scaleY:0.8989,rotation:30,x:348.35,y:262.45},0).wait(1).to({scaleX:0.8787,scaleY:0.8787,rotation:36,y:267.15},0).wait(1).to({scaleX:0.8585,scaleY:0.8585,rotation:42,y:271.8},0).wait(1).to({scaleX:0.8382,scaleY:0.8382,rotation:48,x:348.3,y:276.5},0).wait(1).to({scaleX:0.818,scaleY:0.818,rotation:54,y:281.15},0).wait(1).to({scaleX:0.7978,scaleY:0.7978,rotation:60,y:285.8},0).wait(1).to({scaleX:0.7776,scaleY:0.7776,rotation:66,y:290.45},0).wait(1).to({scaleX:0.7574,scaleY:0.7574,rotation:72,y:295.15},0).wait(1).to({scaleX:0.7372,scaleY:0.7372,rotation:78,x:348.25,y:299.8},0).wait(1).to({scaleX:0.7169,scaleY:0.7169,rotation:84,y:304.45},0).wait(1).to({scaleX:0.6967,scaleY:0.6967,rotation:90,x:348.2,y:309.15},0).wait(1).to({scaleX:0.6765,scaleY:0.6765,rotation:96,y:313.8},0).wait(1).to({scaleX:0.6563,scaleY:0.6563,rotation:102,y:318.45},0).wait(1).to({scaleX:0.636,scaleY:0.636,rotation:108,x:348.15,y:323.15},0).wait(1).to({scaleX:0.6158,scaleY:0.6158,rotation:114,x:348.2,y:327.8},0).wait(1).to({scaleX:0.5956,scaleY:0.5956,rotation:120,y:332.45},0).wait(1).to({scaleX:0.5754,scaleY:0.5754,rotation:126,x:348.15,y:337.1},0).wait(1).to({scaleX:0.5552,scaleY:0.5552,rotation:132,x:348.2,y:341.75},0).wait(1).to({scaleX:0.5349,scaleY:0.5349,rotation:138,x:348.15,y:346.35},0).wait(1).to({scaleX:0.5147,scaleY:0.5147,rotation:144,y:351.05},0).wait(1).to({scaleX:0.4945,scaleY:0.4945,rotation:150,x:348.1,y:355.65},0).wait(1).to({scaleX:0.4743,scaleY:0.4743,rotation:156,y:360.35},0).wait(1).to({scaleX:0.4541,scaleY:0.4541,rotation:162,y:365},0).wait(1).to({scaleX:0.4338,scaleY:0.4338,rotation:168,x:348.15,y:369.7},0).wait(1).to({scaleX:0.4136,scaleY:0.4136,rotation:174,y:374.3},0).wait(1).to({scaleX:0.3934,scaleY:0.3934,rotation:180,y:378.95},0).wait(60).to({_off:true},1).wait(330));

	// Calque_17
	this.instance_184 = new lib.Symbole2();
	this.instance_184.setTransform(52.2,238.4,1,1,0,0,0,69.2,109.4);
	this.instance_184._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_184).wait(539).to({_off:false},0).wait(1).to({regX:69.5,regY:109.6,x:57.5,y:238.6},0).wait(1).to({x:62.5},0).wait(1).to({x:67.5},0).wait(1).to({x:72.5},0).wait(1).to({x:77.5},0).wait(1).to({x:82.5},0).wait(1).to({x:87.5},0).wait(1).to({x:92.5},0).wait(1).to({x:97.5},0).wait(1).to({x:102.5},0).wait(1).to({x:107.5},0).wait(1).to({x:112.5},0).wait(1).to({x:117.5},0).wait(1).to({x:122.5},0).wait(1).to({x:127.5},0).wait(1).to({x:132.5},0).wait(1).to({x:137.5},0).wait(1).to({x:142.5},0).wait(1).to({x:147.5},0).wait(1).to({x:152.5},0).wait(1).to({x:157.5},0).wait(1).to({x:162.5},0).wait(1).to({x:167.5},0).wait(1).to({x:172.5},0).wait(1).to({x:177.5},0).wait(1).to({x:182.5},0).wait(1).to({x:187.5},0).wait(1).to({x:192.5},0).wait(1).to({x:197.5},0).wait(1).to({x:202.5},0).wait(211).to({x:207.25},0).wait(1).to({x:212,y:238.65},0).wait(1).to({x:216.8,y:238.7},0).wait(1).to({x:221.55},0).wait(1).to({x:226.35,y:238.75},0).wait(1).to({x:231.1,y:238.8},0).wait(1).to({x:235.9},0).wait(1).to({x:240.65,y:238.85},0).wait(1).to({x:245.4,y:238.9},0).wait(1).to({x:250.2,y:238.95},0).wait(1).to({x:254.95},0).wait(1).to({x:259.75,y:239},0).wait(1).to({x:264.5,y:239.05},0).wait(1).to({x:269.3},0).wait(1).to({x:274.05,y:239.1},0).wait(1).to({x:278.8,y:239.15},0).wait(1).to({x:283.6},0).wait(1).to({x:288.35,y:239.2},0).wait(1).to({x:293.15,y:239.25},0).wait(1).to({x:297.9,y:239.3},0).wait(1).to({x:302.7},0).wait(1).to({x:307.45,y:239.35},0).wait(1).to({x:312.25,y:239.4},0).wait(1).to({x:317},0).wait(1).to({x:321.75,y:239.45},0).wait(1).to({x:326.55,y:239.5},0).wait(1).to({x:331.3},0).wait(1).to({x:336.1,y:239.55},0).wait(1).to({x:340.85,y:239.6},0).wait(1).to({x:345.65,y:239.65},0).wait(91).to({scaleX:0.9843,scaleY:0.9843,rotation:6,x:345.6,y:244.55},0).wait(1).to({scaleX:0.9685,scaleY:0.9685,rotation:12,y:249.45},0).wait(1).to({scaleX:0.9528,scaleY:0.9528,rotation:18,x:345.5,y:254.25},0).wait(1).to({scaleX:0.937,scaleY:0.937,rotation:24,y:259.15},0).wait(1).to({scaleX:0.9213,scaleY:0.9213,rotation:30,x:345.45,y:264.05},0).wait(1).to({scaleX:0.9055,scaleY:0.9055,rotation:36,x:345.4,y:268.95},0).wait(1).to({scaleX:0.8898,scaleY:0.8898,rotation:42,y:273.8},0).wait(1).to({scaleX:0.874,scaleY:0.874,rotation:48,x:345.35,y:278.65},0).wait(1).to({scaleX:0.8583,scaleY:0.8583,rotation:54,x:345.3,y:283.5},0).wait(1).to({scaleX:0.8425,scaleY:0.8425,rotation:60,y:288.35},0).wait(1).to({scaleX:0.8268,scaleY:0.8268,rotation:66,x:345.2,y:293.2},0).wait(1).to({scaleX:0.811,scaleY:0.811,rotation:72,y:298.05},0).wait(1).to({scaleX:0.7953,scaleY:0.7953,rotation:78,y:302.9},0).wait(1).to({scaleX:0.7795,scaleY:0.7795,rotation:84,x:345.15,y:307.8},0).wait(1).to({scaleX:0.7638,scaleY:0.7638,rotation:90,y:312.6},0).wait(1).to({scaleX:0.748,scaleY:0.748,rotation:96,x:345.1,y:317.45},0).wait(1).to({scaleX:0.7323,scaleY:0.7323,rotation:102,y:322.3},0).wait(1).to({scaleX:0.7165,scaleY:0.7165,rotation:108,x:345.05,y:327.15},0).wait(1).to({scaleX:0.7008,scaleY:0.7008,rotation:114,x:345.1,y:331.95},0).wait(1).to({scaleX:0.685,scaleY:0.685,rotation:120,y:336.8},0).wait(1).to({scaleX:0.6693,scaleY:0.6693,rotation:126,x:345.05,y:341.65},0).wait(1).to({scaleX:0.6535,scaleY:0.6535,rotation:132,y:346.45},0).wait(1).to({scaleX:0.6378,scaleY:0.6378,rotation:138,x:345.1,y:351.3},0).wait(1).to({scaleX:0.622,scaleY:0.622,rotation:144,x:345.15,y:356.15},0).wait(1).to({scaleX:0.6063,scaleY:0.6063,rotation:150,x:345.1,y:361},0).wait(1).to({scaleX:0.5906,scaleY:0.5906,rotation:156,x:345.15,y:365.85},0).wait(1).to({scaleX:0.5748,scaleY:0.5748,rotation:162,y:370.7},0).wait(1).to({scaleX:0.5591,scaleY:0.5591,rotation:168,y:375.55},0).wait(1).to({scaleX:0.5433,scaleY:0.5433,rotation:174,x:345.2,y:380.4},0).wait(1).to({scaleX:0.5276,scaleY:0.5276,rotation:180,y:385.25},0).to({_off:true},1).wait(750));

	// Calque_29
	this.text_11 = new cjs.Text("Un étudiant tire sur la cible. \nLe canard rose est mort.", "italic 30px 'Harlow Solid Italic'");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 40;
	this.text_11.lineWidth = 505;
	this.text_11.parent = this;
	this.text_11.setTransform(312.35,-82.7);

	this.timeline.addTween(cjs.Tween.get(this.text_11).to({_off:true},749).wait(90).to({_off:false,y:-75.7,text:"Un étudiant tire sur la cible. "},0).wait(1).to({y:-73.7575},0).wait(1).to({y:-71.815},0).wait(1).to({y:-69.8725},0).wait(1).to({y:-67.93},0).wait(1).to({y:-65.9875},0).wait(1).to({y:-64.045},0).wait(1).to({y:-62.1025},0).wait(1).to({y:-60.16},0).wait(1).to({y:-58.2175},0).wait(1).to({y:-56.275},0).wait(1).to({y:-54.3325},0).wait(1).to({y:-52.39},0).wait(1).to({y:-50.4475},0).wait(1).to({y:-48.505},0).wait(1).to({y:-46.5625},0).wait(1).to({y:-44.62},0).wait(1).to({y:-42.6775},0).wait(1).to({y:-40.735},0).wait(1).to({y:-38.7925},0).wait(1).to({y:-36.85},0).wait(1).to({y:-34.9075},0).wait(1).to({y:-32.965},0).wait(1).to({y:-31.0225},0).wait(1).to({y:-29.08},0).wait(1).to({y:-27.1375},0).wait(1).to({y:-25.195},0).wait(1).to({y:-23.2525},0).wait(1).to({y:-21.31},0).wait(1).to({y:-19.3675},0).wait(1).to({y:-17.425},0).wait(1).to({y:-15.4825},0).wait(1).to({y:-13.54},0).wait(1).to({y:-11.5975},0).wait(1).to({y:-9.655},0).wait(1).to({y:-7.7125},0).wait(1).to({y:-5.77},0).wait(1).to({y:-3.8275},0).wait(1).to({y:-1.885},0).wait(1).to({y:0.0575},0).wait(1).to({y:2},0).wait(51).to({x:329.89},0).wait(1).to({x:347.43},0).wait(1).to({x:364.97},0).wait(1).to({x:382.51},0).wait(1).to({x:400.05},0).wait(1).to({x:417.59},0).wait(1).to({x:435.13},0).wait(1).to({x:452.67},0).wait(1).to({x:470.21},0).wait(1).to({x:487.75},0).wait(1).to({x:505.29},0).wait(1).to({x:522.83},0).wait(1).to({x:540.37},0).wait(1).to({x:557.91},0).wait(1).to({x:575.45},0).wait(1).to({x:592.99},0).wait(1).to({x:610.53},0).wait(1).to({x:628.07},0).wait(1).to({x:645.61},0).wait(1).to({x:663.15},0).wait(1).to({x:680.69},0).wait(1).to({x:698.23},0).wait(1).to({x:715.77},0).wait(1).to({x:733.31},0).wait(1).to({x:750.85},0).wait(1).to({x:768.39},0).wait(1).to({x:785.93},0).wait(1).to({x:803.47},0).wait(1).to({x:821.01},0).wait(1).to({x:838.55},0).to({_off:true},1).wait(720));

	// Calque_16
	this.instance_185 = new lib.Canardjaune();
	this.instance_185.setTransform(-17,129,0.3756,0.3756);

	this.instance_186 = new lib.Symbole6();
	this.instance_186.setTransform(52.1,237.9,1,1,0,0,0,69.1,108.9);
	this.instance_186._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_185}]},539).to({state:[{t:this.instance_185}]},59).to({state:[{t:this.instance_186}]},61).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[{t:this.instance_186}]},1).to({state:[]},1).wait(180));
	this.timeline.addTween(cjs.Tween.get(this.instance_186).wait(659).to({_off:false},0).wait(121).to({x:57.1},0).wait(1).to({x:62.05},0).wait(1).to({x:67},0).wait(1).to({x:71.95},0).wait(1).to({x:76.9},0).wait(1).to({x:81.9},0).wait(1).to({x:86.85},0).wait(1).to({x:91.8},0).wait(1).to({x:96.8},0).wait(1).to({x:101.75},0).wait(1).to({x:106.7},0).wait(1).to({x:111.7},0).wait(1).to({x:116.65},0).wait(1).to({x:121.6},0).wait(1).to({x:126.6},0).wait(1).to({x:131.55},0).wait(1).to({x:136.5},0).wait(1).to({x:141.5},0).wait(1).to({x:146.45},0).wait(1).to({x:151.4},0).wait(1).to({x:156.4},0).wait(1).to({x:161.35},0).wait(1).to({x:166.3},0).wait(1).to({x:171.3},0).wait(1).to({x:176.25},0).wait(1).to({x:181.2},0).wait(1).to({x:186.2},0).wait(1).to({x:191.15},0).wait(1).to({x:196.1},0).wait(1).to({x:201.1},0).wait(121).to({x:206.05},0).wait(1).to({x:211,y:237.95},0).wait(1).to({x:216,y:238},0).wait(1).to({x:220.95},0).wait(1).to({x:225.9,y:238.05},0).wait(1).to({x:230.9,y:238.1},0).wait(1).to({x:235.85},0).wait(1).to({x:240.8,y:238.15},0).wait(1).to({x:245.8,y:238.2},0).wait(1).to({x:250.75,y:238.25},0).wait(1).to({x:255.7},0).wait(1).to({x:260.7,y:238.3},0).wait(1).to({x:265.65,y:238.35},0).wait(1).to({x:270.6},0).wait(1).to({x:275.6,y:238.4},0).wait(1).to({x:280.55,y:238.45},0).wait(1).to({x:285.5},0).wait(1).to({x:290.5,y:238.5},0).wait(1).to({x:295.45,y:238.55},0).wait(1).to({x:300.4,y:238.6},0).wait(1).to({x:305.4},0).wait(1).to({x:310.35,y:238.65},0).wait(1).to({x:315.3,y:238.7},0).wait(1).to({x:320.3},0).wait(1).to({x:325.25,y:238.75},0).wait(1).to({x:330.2,y:238.8},0).wait(1).to({x:335.2},0).wait(1).to({x:340.15,y:238.85},0).wait(1).to({x:345.1,y:238.9},0).wait(1).to({x:350.1,y:238.95},0).wait(181).to({x:355.25},0).wait(1).to({x:360.45},0).wait(1).to({x:365.6},0).wait(1).to({x:370.8},0).wait(1).to({x:375.95},0).wait(1).to({x:381.15,y:239},0).wait(1).to({x:386.3},0).wait(1).to({x:391.5},0).wait(1).to({x:396.65},0).wait(1).to({x:401.85},0).wait(1).to({x:407},0).wait(1).to({x:412.2,y:239.05},0).wait(1).to({x:417.35},0).wait(1).to({x:422.55},0).wait(1).to({x:427.7},0).wait(1).to({x:432.9},0).wait(1).to({x:438.05},0).wait(1).to({x:443.25,y:239.1},0).wait(1).to({x:448.4},0).wait(1).to({x:453.6},0).wait(1).to({x:458.75},0).wait(1).to({x:463.95},0).wait(1).to({x:469.1},0).wait(1).to({x:474.3,y:239.15},0).wait(1).to({x:479.45},0).wait(1).to({x:484.65},0).wait(1).to({x:489.8},0).wait(1).to({x:495},0).wait(1).to({x:500.15},0).wait(1).to({x:505.35,y:239.2},0).wait(211).to({x:510.15},0).wait(1).to({x:515},0).wait(1).to({x:519.85},0).wait(1).to({x:524.65},0).wait(1).to({x:529.5},0).wait(1).to({x:534.35},0).wait(1).to({x:539.15},0).wait(1).to({x:544},0).wait(1).to({x:548.85},0).wait(1).to({x:553.65},0).wait(1).to({x:558.5},0).wait(1).to({x:563.35},0).wait(1).to({x:568.15},0).wait(1).to({x:573},0).wait(1).to({x:577.85},0).wait(1).to({x:582.65},0).wait(1).to({x:587.5},0).wait(1).to({x:592.35},0).wait(1).to({x:597.15},0).wait(1).to({x:602},0).wait(1).to({x:606.85},0).wait(1).to({x:611.65},0).wait(1).to({x:616.5},0).wait(1).to({x:621.35},0).wait(1).to({x:626.15},0).wait(1).to({x:631},0).wait(1).to({x:635.85},0).wait(1).to({x:640.65},0).wait(1).to({x:645.5},0).wait(1).to({x:650.35},0).wait(90).to({_off:true},1).wait(180));

	// Calque_15
	this.text_12 = new cjs.Text("Cependant, les étudiants doivent d'abord viser\nune cible, avant de pouvoir tirer.\nCe qui permet à certains canards \nde sortir vivant de cette dangeureuse migration", "italic 30px 'Harlow Solid Italic'");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 40;
	this.text_12.lineWidth = 597;
	this.text_12.parent = this;
	this.text_12.setTransform(300.6,72.8);
	this.text_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_12).wait(285).to({_off:false},0).wait(1).to({scaleX:0.2292,scaleY:0.2292,x:300.6192,y:136.0079},0).wait(1).to({scaleX:0.2341,scaleY:0.2341,x:300.6032,y:135.4864},0).wait(1).to({scaleX:0.239,scaleY:0.239,x:300.5871,y:134.9648},0).wait(1).to({scaleX:0.2439,scaleY:0.2439,x:300.6211,y:134.4433},0).wait(1).to({scaleX:0.2488,scaleY:0.2488,x:300.6051,y:133.9218},0).wait(1).to({scaleX:0.2537,scaleY:0.2537,x:300.589,y:133.4002},0).wait(1).to({scaleX:0.2586,scaleY:0.2586,x:300.573,y:132.8787},0).wait(1).to({scaleX:0.2635,scaleY:0.2635,x:300.6069,y:132.3572},0).wait(1).to({scaleX:0.2684,scaleY:0.2684,x:300.5909,y:131.8357},0).wait(1).to({scaleX:0.2734,scaleY:0.2734,x:300.5748,y:131.3141},0).wait(1).to({scaleX:0.2783,scaleY:0.2783,x:300.6088,y:130.7926},0).wait(1).to({scaleX:0.2832,scaleY:0.2832,x:300.5927,y:130.2711},0).wait(1).to({scaleX:0.2881,scaleY:0.2881,x:300.5767,y:129.7495},0).wait(1).to({scaleX:0.293,scaleY:0.293,x:300.6106,y:129.228},0).wait(1).to({scaleX:0.2979,scaleY:0.2979,x:300.5946,y:128.7065},0).wait(1).to({scaleX:0.3028,scaleY:0.3028,x:300.5785,y:128.1849},0).wait(1).to({scaleX:0.3077,scaleY:0.3077,x:300.6125,y:127.6634},0).wait(1).to({scaleX:0.3126,scaleY:0.3126,x:300.5965,y:127.1419},0).wait(1).to({scaleX:0.3175,scaleY:0.3175,x:300.5804,y:126.6204},0).wait(1).to({scaleX:0.3225,scaleY:0.3225,x:300.6144,y:126.0988},0).wait(1).to({scaleX:0.3274,scaleY:0.3274,x:300.5983,y:125.5773},0).wait(1).to({scaleX:0.3323,scaleY:0.3323,x:300.5823,y:125.0558},0).wait(1).to({scaleX:0.3372,scaleY:0.3372,x:300.6162,y:124.5342},0).wait(1).to({scaleX:0.3421,scaleY:0.3421,x:300.6002,y:124.0127},0).wait(1).to({scaleX:0.347,scaleY:0.347,x:300.5841,y:123.4912},0).wait(1).to({scaleX:0.3519,scaleY:0.3519,x:300.6181,y:122.9696},0).wait(1).to({scaleX:0.3568,scaleY:0.3568,x:300.602,y:122.4481},0).wait(1).to({scaleX:0.3617,scaleY:0.3617,x:300.586,y:121.9266},0).wait(1).to({scaleX:0.3666,scaleY:0.3666,x:300.6199,y:121.4051},0).wait(1).to({scaleX:0.3716,scaleY:0.3716,x:300.6039,y:120.8835},0).wait(1).to({scaleX:0.3765,scaleY:0.3765,x:300.5879,y:120.362},0).wait(1).to({scaleX:0.3814,scaleY:0.3814,x:300.5718,y:119.8405},0).wait(1).to({scaleX:0.3863,scaleY:0.3863,x:300.6058,y:119.3189},0).wait(1).to({scaleX:0.3912,scaleY:0.3912,x:300.5897,y:118.7974},0).wait(1).to({scaleX:0.3961,scaleY:0.3961,x:300.5737,y:118.2759},0).wait(1).to({scaleX:0.401,scaleY:0.401,x:300.6076,y:117.7543},0).wait(1).to({scaleX:0.4059,scaleY:0.4059,x:300.5916,y:117.2328},0).wait(1).to({scaleX:0.4108,scaleY:0.4108,x:300.5755,y:116.7113},0).wait(1).to({scaleX:0.4157,scaleY:0.4157,x:300.6095,y:116.1898},0).wait(1).to({scaleX:0.4207,scaleY:0.4207,x:300.5934,y:115.6682},0).wait(1).to({scaleX:0.4256,scaleY:0.4256,x:300.5774,y:115.1467},0).wait(1).to({scaleX:0.4305,scaleY:0.4305,x:300.6113,y:114.6252},0).wait(1).to({scaleX:0.4354,scaleY:0.4354,x:300.5953,y:114.1036},0).wait(1).to({scaleX:0.4403,scaleY:0.4403,x:300.5793,y:113.5821},0).wait(1).to({scaleX:0.4452,scaleY:0.4452,x:300.6132,y:113.0606},0).wait(1).to({scaleX:0.4501,scaleY:0.4501,x:300.5972,y:112.539},0).wait(1).to({scaleX:0.455,scaleY:0.455,x:300.5811,y:112.0175},0).wait(1).to({scaleX:0.4599,scaleY:0.4599,x:300.6151,y:111.496},0).wait(1).to({scaleX:0.4648,scaleY:0.4648,x:300.599,y:110.9745},0).wait(1).to({scaleX:0.4697,scaleY:0.4697,x:300.583,y:110.4529},0).wait(1).to({scaleX:0.4747,scaleY:0.4747,x:300.6169,y:109.9314},0).wait(1).to({scaleX:0.4796,scaleY:0.4796,x:300.6009,y:109.4099},0).wait(1).to({scaleX:0.4845,scaleY:0.4845,x:300.5848,y:108.8883},0).wait(1).to({scaleX:0.4894,scaleY:0.4894,x:300.6188,y:108.3668},0).wait(1).to({scaleX:0.4943,scaleY:0.4943,x:300.6028,y:107.8453},0).wait(1).to({scaleX:0.4992,scaleY:0.4992,x:300.5867,y:107.3237},0).wait(1).to({scaleX:0.5041,scaleY:0.5041,x:300.6207,y:106.8022},0).wait(1).to({scaleX:0.509,scaleY:0.509,x:300.6046,y:106.2807},0).wait(1).to({scaleX:0.5139,scaleY:0.5139,x:300.5886,y:105.7592},0).wait(1).to({scaleX:0.5188,scaleY:0.5188,x:300.6225,y:105.2376},0).wait(1).to({scaleX:0.5238,scaleY:0.5238,x:300.6065,y:104.7161},0).wait(1).to({scaleX:0.5287,scaleY:0.5287,x:300.5904,y:104.1946},0).wait(1).to({scaleX:0.5336,scaleY:0.5336,x:300.5744,y:103.673},0).wait(1).to({scaleX:0.5385,scaleY:0.5385,x:300.6083,y:103.1515},0).wait(1).to({scaleX:0.5434,scaleY:0.5434,x:300.5923,y:102.63},0).wait(1).to({scaleX:0.5483,scaleY:0.5483,x:300.5762,y:102.1084},0).wait(1).to({scaleX:0.5532,scaleY:0.5532,x:300.6102,y:101.5869},0).wait(1).to({scaleX:0.5581,scaleY:0.5581,x:300.5942,y:101.0654},0).wait(1).to({scaleX:0.563,scaleY:0.563,x:300.5781,y:100.5438},0).wait(1).to({scaleX:0.5679,scaleY:0.5679,x:300.6121,y:100.0223},0).wait(1).to({scaleX:0.5729,scaleY:0.5729,x:300.596,y:99.5008},0).wait(1).to({scaleX:0.5778,scaleY:0.5778,x:300.58,y:98.9793},0).wait(1).to({scaleX:0.5827,scaleY:0.5827,x:300.6139,y:98.4577},0).wait(1).to({scaleX:0.5876,scaleY:0.5876,x:300.5979,y:97.9362},0).wait(1).to({scaleX:0.5925,scaleY:0.5925,x:300.5818,y:97.4147},0).wait(1).to({scaleX:0.5974,scaleY:0.5974,x:300.6158,y:96.8931},0).wait(1).to({scaleX:0.6023,scaleY:0.6023,x:300.5997,y:96.3716},0).wait(1).to({scaleX:0.6072,scaleY:0.6072,x:300.5837,y:95.8501},0).wait(1).to({scaleX:0.6121,scaleY:0.6121,x:300.6176,y:95.3285},0).wait(1).to({scaleX:0.617,scaleY:0.617,x:300.6016,y:94.807},0).wait(1).to({scaleX:0.622,scaleY:0.622,x:300.5856,y:94.2855},0).wait(1).to({scaleX:0.6269,scaleY:0.6269,x:300.6195,y:93.764},0).wait(1).to({scaleX:0.6318,scaleY:0.6318,x:300.6035,y:93.2424},0).wait(1).to({scaleX:0.6367,scaleY:0.6367,x:300.5874,y:92.7209},0).wait(1).to({scaleX:0.6416,scaleY:0.6416,x:300.6214,y:92.1994},0).wait(1).to({scaleX:0.6465,scaleY:0.6465,x:300.6053,y:91.6778},0).wait(1).to({scaleX:0.6514,scaleY:0.6514,x:300.5893,y:91.1563},0).wait(1).to({scaleX:0.6563,scaleY:0.6563,x:300.5732,y:90.6348},0).wait(1).to({scaleX:0.6612,scaleY:0.6612,x:300.6072,y:90.1132},0).wait(1).to({scaleX:0.6661,scaleY:0.6661,x:300.5911,y:89.5917},0).wait(1).to({scaleX:0.671,scaleY:0.671,x:300.5751,y:89.0702},0).wait(1).to({scaleX:0.676,scaleY:0.676,x:300.609,y:88.5487},0).wait(1).to({scaleX:0.6809,scaleY:0.6809,x:300.593,y:88.0271},0).wait(1).to({scaleX:0.6858,scaleY:0.6858,x:300.577,y:87.5056},0).wait(1).to({scaleX:0.6907,scaleY:0.6907,x:300.6109,y:86.9841},0).wait(1).to({scaleX:0.6956,scaleY:0.6956,x:300.5949,y:86.4625},0).wait(1).to({scaleX:0.7005,scaleY:0.7005,x:300.5788,y:85.941},0).wait(1).to({scaleX:0.7054,scaleY:0.7054,x:300.6128,y:85.4195},0).wait(1).to({scaleX:0.7103,scaleY:0.7103,x:300.5967,y:84.8979},0).wait(1).to({scaleX:0.7152,scaleY:0.7152,x:300.5807,y:84.3764},0).wait(1).to({scaleX:0.7201,scaleY:0.7201,x:300.6146,y:83.8549},0).wait(1).to({scaleX:0.7251,scaleY:0.7251,x:300.5986,y:83.3334},0).wait(1).to({scaleX:0.73,scaleY:0.73,x:300.5825,y:82.8118},0).wait(1).to({scaleX:0.7349,scaleY:0.7349,x:300.6165,y:82.2903},0).wait(1).to({scaleX:0.7398,scaleY:0.7398,x:300.6004,y:81.8118},0).wait(1).to({scaleX:0.7447,scaleY:0.7447,x:300.5844,y:81.3332},0).wait(1).to({scaleX:0.7496,scaleY:0.7496,x:300.6184,y:80.8547},0).wait(1).to({scaleX:0.7545,scaleY:0.7545,x:300.6023,y:80.3762},0).wait(1).to({scaleX:0.7594,scaleY:0.7594,x:300.5863,y:79.8977},0).wait(1).to({scaleX:0.7643,scaleY:0.7643,x:300.6202,y:79.4192},0).wait(1).to({scaleX:0.7692,scaleY:0.7692,x:300.6042,y:78.9406},0).wait(1).to({scaleX:0.7742,scaleY:0.7742,x:300.5881,y:78.4621},0).wait(1).to({scaleX:0.7791,scaleY:0.7791,x:300.6221,y:77.9836},0).wait(1).to({scaleX:0.784,scaleY:0.784,x:300.606,y:77.5051},0).wait(1).to({scaleX:0.7889,scaleY:0.7889,x:300.59,y:77.0265},0).wait(1).to({scaleX:0.7938,scaleY:0.7938,x:300.5739,y:76.548},0).wait(1).to({scaleX:0.7987,scaleY:0.7987,x:300.6079,y:76.0695},0).wait(1).to({scaleX:0.8036,scaleY:0.8036,x:300.5918,y:75.591},0).wait(1).to({scaleX:0.8085,scaleY:0.8085,x:300.5758,y:75.1124},0).wait(1).to({scaleX:0.8134,scaleY:0.8134,x:300.6098,y:74.6339},0).wait(1).to({scaleX:0.8183,scaleY:0.8183,x:300.5937,y:74.1554},0).wait(1).to({scaleX:0.8232,scaleY:0.8232,x:300.5777,y:73.6769},0).wait(1).to({scaleX:0.8282,scaleY:0.8282,x:300.6116,y:73.1983},0).wait(1).to({scaleX:0.8331,scaleY:0.8331,x:300.5956,y:72.7198},0).wait(1).to({scaleX:0.838,scaleY:0.838,x:300.5795,y:72.2413},0).wait(1).to({scaleX:0.8429,scaleY:0.8429,x:300.6135,y:71.7628},0).wait(1).to({scaleX:0.8478,scaleY:0.8478,x:300.5974,y:71.2842},0).wait(1).to({scaleX:0.8527,scaleY:0.8527,x:300.5814,y:70.8057},0).wait(1).to({scaleX:0.8576,scaleY:0.8576,x:300.6153,y:70.3272},0).wait(1).to({scaleX:0.8625,scaleY:0.8625,x:300.5993,y:69.8487},0).wait(1).to({scaleX:0.8674,scaleY:0.8674,x:300.5832,y:69.3701},0).wait(1).to({scaleX:0.8723,scaleY:0.8723,x:300.6172,y:68.8916},0).wait(1).to({scaleX:0.8773,scaleY:0.8773,x:300.6012,y:68.4131},0).wait(1).to({scaleX:0.8822,scaleY:0.8822,x:300.5851,y:67.9346},0).wait(1).to({scaleX:0.8871,scaleY:0.8871,x:300.6191,y:67.4561},0).wait(1).to({scaleX:0.892,scaleY:0.892,x:300.603,y:66.9775},0).wait(1).to({scaleX:0.8969,scaleY:0.8969,x:300.587,y:66.499},0).wait(1).to({scaleX:0.9018,scaleY:0.9018,x:300.6209,y:66.0205},0).wait(1).to({scaleX:0.9067,scaleY:0.9067,x:300.6049,y:65.542},0).wait(1).to({scaleX:0.9116,scaleY:0.9116,x:300.5888,y:65.0634},0).wait(1).to({scaleX:0.9165,scaleY:0.9165,x:300.6228,y:64.5849},0).wait(1).to({scaleX:0.9214,scaleY:0.9214,x:300.6067,y:64.1064},0).wait(1).to({scaleX:0.9264,scaleY:0.9264,x:300.5907,y:63.6279},0).wait(1).to({scaleX:0.9313,scaleY:0.9313,x:300.5746,y:63.1493},0).wait(1).to({scaleX:0.9362,scaleY:0.9362,x:300.6086,y:62.6708},0).wait(1).to({scaleX:0.9411,scaleY:0.9411,x:300.5926,y:62.1923},0).wait(1).to({scaleX:0.946,scaleY:0.946,x:300.5765,y:61.7138},0).wait(1).to({scaleX:0.9509,scaleY:0.9509,x:300.6105,y:61.2352},0).wait(1).to({scaleX:0.9558,scaleY:0.9558,x:300.5944,y:60.7567},0).wait(1).to({scaleX:0.9607,scaleY:0.9607,x:300.5784,y:60.2782},0).wait(1).to({scaleX:0.9656,scaleY:0.9656,x:300.6123,y:59.7997},0).wait(1).to({scaleX:0.9705,scaleY:0.9705,x:300.5963,y:59.3211},0).wait(1).to({scaleX:0.9755,scaleY:0.9755,x:300.5802,y:58.8426},0).wait(1).to({scaleX:0.9804,scaleY:0.9804,x:300.6142,y:58.3641},0).wait(1).to({scaleX:0.9853,scaleY:0.9853,x:300.5981,y:57.8856},0).wait(1).to({scaleX:0.9902,scaleY:0.9902,x:300.5821,y:57.407},0).wait(1).to({scaleX:0.9951,scaleY:0.9951,x:300.616,y:56.9285},0).wait(1).to({scaleX:1,scaleY:1,x:300.6,y:56.45},0).wait(95).to({_off:true},1).wait(1141));

	// Calque_27
	this.text_13 = new cjs.Text("Le canard bleu avance", "italic 30px 'Harlow Solid Italic'");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 40;
	this.text_13.lineWidth = 598;
	this.text_13.parent = this;
	this.text_13.setTransform(301.1,-37.45);
	this.text_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_13).wait(749).to({_off:false},0).wait(1).to({y:-35.7483},0).wait(1).to({y:-34.0467},0).wait(1).to({y:-32.345},0).wait(1).to({y:-30.6433},0).wait(1).to({y:-28.9417},0).wait(1).to({y:-27.24},0).wait(1).to({y:-25.5383},0).wait(1).to({y:-23.8367},0).wait(1).to({y:-22.135},0).wait(1).to({y:-20.4333},0).wait(1).to({y:-18.7317},0).wait(1).to({y:-17.03},0).wait(1).to({y:-15.3283},0).wait(1).to({y:-13.6267},0).wait(1).to({y:-11.925},0).wait(1).to({y:-10.2233},0).wait(1).to({y:-8.5217},0).wait(1).to({y:-6.82},0).wait(1).to({y:-5.1183},0).wait(1).to({y:-3.4167},0).wait(1).to({y:-1.715},0).wait(1).to({y:-0.0133},0).wait(1).to({y:1.6883},0).wait(1).to({y:3.39},0).wait(1).to({y:5.0917},0).wait(1).to({y:6.7933},0).wait(1).to({y:8.495},0).wait(1).to({y:10.1967},0).wait(1).to({y:11.8983},0).wait(1).to({y:13.6},0).wait(39).to({x:321.2818,y:13.4386},0).wait(1).to({x:341.4636,y:13.2773},0).wait(1).to({x:361.6455,y:13.1159},0).wait(1).to({x:381.8273,y:12.9545},0).wait(1).to({x:402.0091,y:12.7932},0).wait(1).to({x:422.1909,y:12.6318},0).wait(1).to({x:442.3727,y:12.4705},0).wait(1).to({x:462.5545,y:12.3091},0).wait(1).to({x:482.7364,y:12.1477},0).wait(1).to({x:502.9182,y:11.9864},0).wait(1).to({x:523.1,y:11.825},0).wait(1).to({x:543.2818,y:11.6636},0).wait(1).to({x:563.4636,y:11.5023},0).wait(1).to({x:583.6455,y:11.3409},0).wait(1).to({x:603.8273,y:11.1795},0).wait(1).to({x:624.0091,y:11.0182},0).wait(1).to({x:644.1909,y:10.8568},0).wait(1).to({x:664.3727,y:10.6955},0).wait(1).to({x:684.5545,y:10.5341},0).wait(1).to({x:704.7364,y:10.3727},0).wait(1).to({x:724.9182,y:10.2114},0).wait(1).to({x:745.1,y:10.05},0).to({_off:true},1).wait(840));

	// Calque_23
	this.instance_187 = new lib.marshlandscapeillustrationvector();
	this.instance_187.setTransform(-38,-18);

	this.timeline.addTween(cjs.Tween.get(this.instance_187).wait(1680));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-198.9,41,1352.9,475.1);
// library properties:
lib.properties = {
	id: '0A31871B1A2BD4428AF2AD48D408CEB5',
	width: 600,
	height: 360,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/anim htlm 2_atlas_.png", id:"anim htlm 2_atlas_"},
		{src:"images/anim htlm 2_atlas_2.png", id:"anim htlm 2_atlas_2"},
		{src:"sounds/_0438.mp3", id:"_0438"},
		{src:"sounds/_0438mp3copy.mp3", id:"_0438mp3copy"},
		{src:"sounds/GAMEBOYADVANCEADVANCESPMICROStartupSound.mp3", id:"GAMEBOYADVANCEADVANCESPMICROStartupSound"},
		{src:"sounds/podcastmúsicadefondo.mp3", id:"podcastmúsicadefondo"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['0A31871B1A2BD4428AF2AD48D408CEB5'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;